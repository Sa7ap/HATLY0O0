import 'package:flutter_bloc/flutter_bloc.dart';

import '../../domain/usecases/create_order_usecase.dart';
import '../../domain/usecases/update_order_status_usecase.dart';
import '../../domain/usecases/get_notifications_usecase.dart';
import '../../domain/usecases/submit_order_evaluation_usecase.dart';
import '../../domain/usecases/get_order_history_usecase.dart';
import '../../domain/usecases/get_chat_messages_usecase.dart';
import '../../domain/usecases/send_chat_message_usecase.dart';
import '../../domain/usecases/get_saved_addresses_usecase.dart';
import '../../domain/usecases/save_new_address_usecase.dart';
import '../../domain/usecases/update_customer_profile_usecase.dart';
import '../../domain/usecases/process_order_payment_usecase.dart'; // الاستيراد الجديد هنا
import 'customer_order_event.dart';
import 'customer_order_state.dart';

class CustomerOrderBloc extends Bloc<CustomerOrderEvent, CustomerOrderState> {
  final CreateOrderUseCase createOrderUseCase;
  final UpdateOrderStatusUseCase updateOrderStatusUseCase;
  final GetNotificationsUseCase getNotificationsUseCase;
  final SubmitOrderEvaluationUseCase submitOrderEvaluationUseCase;
  final GetOrderHistoryUseCase getOrderHistoryUseCase;
  final GetChatMessagesUseCase getChatMessagesUseCase;
  final SendChatMessageUseCase sendChatMessageUseCase;
  final GetSavedAddressesUseCase getSavedAddressesUseCase;
  final SaveNewAddressUseCase saveNewAddressUseCase;
  final UpdateCustomerProfileUseCase updateCustomerProfileUseCase;
  final ProcessOrderPaymentUseCase
  processOrderPaymentUseCase; // التبعية الحادية عشرة المضافة

  CustomerOrderBloc({
    required this.createOrderUseCase,
    required this.updateOrderStatusUseCase,
    required this.getNotificationsUseCase,
    required this.submitOrderEvaluationUseCase,
    required this.getOrderHistoryUseCase,
    required this.getChatMessagesUseCase,
    required this.sendChatMessageUseCase,
    required this.getSavedAddressesUseCase,
    required this.saveNewAddressUseCase,
    required this.updateCustomerProfileUseCase,
    required this.processOrderPaymentUseCase, // إلزام التبعية في الـ Constructor
  }) : super(CustomerOrderInitialState()) {
    on<CreateOrderRequestedEvent>((event, emit) async {
      emit(CustomerOrderLoadingState());
      await Future.delayed(const Duration(seconds: 1));
      emit(CreateOrderSuccessState());
    });

    on<UpdateOrderStatusRequestedEvent>((event, emit) async {
      emit(CustomerOrderLoadingState());
      final result = await updateOrderStatusUseCase.call(
        orderId: event.orderId,
        newStatus: event.newStatus,
      );
      result.fold(
        (failure) =>
            emit(CustomerOrderFailureState(errorMessage: failure.message)),
        (_) => emit(
          UpdateOrderStatusSuccessState(
            orderId: event.orderId,
            newStatus: event.newStatus,
          ),
        ),
      );
    });

    on<GetNotificationsEvent>((event, emit) async {
      emit(CustomerOrderLoadingState());
      final result = await getNotificationsUseCase.call();
      result.fold(
        (failure) =>
            emit(CustomerOrderFailureState(errorMessage: failure.message)),
        (notifications) =>
            emit(GetNotificationsSuccessState(notifications: notifications)),
      );
    });
    // يتبع مباشرة وتلقائياً الجزء 2 من 2 بالرد القادم...
    on<StartOrderTrackingEvent>((event, emit) async {
      emit(CustomerOrderLoadingState());
      await Future.delayed(const Duration(milliseconds: 800));
      emit(
        GetOrderTrackingSuccessState(
          orderId: event.orderId,
          currentStage: '4',
          captainLatitude: 30.9575,
          captainLongitude: 31.2594,
        ),
      );
    });

    on<SubmitOrderEvaluationEvent>((event, emit) async {
      emit(CustomerOrderLoadingState());
      final result = await submitOrderEvaluationUseCase.call(event.evaluation);
      result.fold(
        (failure) =>
            emit(CustomerOrderFailureState(errorMessage: failure.message)),
        (_) => emit(SubmitOrderEvaluationSuccessState()),
      );
    });

    on<GetOrderHistoryEvent>((event, emit) async {
      emit(CustomerOrderLoadingState());
      final result = await getOrderHistoryUseCase.call();
      result.fold(
        (failure) =>
            emit(CustomerOrderFailureState(errorMessage: failure.message)),
        (pastOrders) => emit(GetOrderHistorySuccessState(orders: pastOrders)),
      );
    });

    on<GetChatMessagesEvent>((event, emit) async {
      emit(CustomerOrderLoadingState());
      final result = await getChatMessagesUseCase.call(event.orderId);
      result.fold(
        (failure) =>
            emit(CustomerOrderFailureState(errorMessage: failure.message)),
        (chatMessages) =>
            emit(GetChatMessagesSuccessState(messages: chatMessages)),
      );
    });

    on<SendChatMessageEvent>((event, emit) async {
      final result = await sendChatMessageUseCase.call(
        event.orderId,
        event.message,
      );
      result.fold(
        (failure) =>
            emit(CustomerOrderFailureState(errorMessage: failure.message)),
        (_) => emit(SendChatMessageSuccessState()),
      );
    });

    on<GetSavedAddressesEvent>((event, emit) async {
      emit(CustomerOrderLoadingState());
      final result = await getSavedAddressesUseCase.call();
      result.fold(
        (failure) =>
            emit(CustomerOrderFailureState(errorMessage: failure.message)),
        (addressesList) =>
            emit(GetSavedAddressesSuccessState(addresses: addressesList)),
      );
    });

    on<SaveNewAddressEvent>((event, emit) async {
      emit(CustomerOrderLoadingState());
      final result = await saveNewAddressUseCase.call(event.address);
      result.fold(
        (failure) =>
            emit(CustomerOrderFailureState(errorMessage: failure.message)),
        (_) => emit(SaveNewAddressSuccessState()),
      );
    });

    on<UpdateCustomerProfileEvent>((event, emit) async {
      emit(CustomerOrderLoadingState());
      final result = await updateCustomerProfileUseCase.call(
        name: event.name,
        phone: event.phone,
      );
      result.fold(
        (failure) =>
            emit(CustomerOrderFailureState(errorMessage: failure.message)),
        (_) => emit(UpdateCustomerProfileSuccessState()),
      );
    });

    // --- الحدث الجديد المضاف: معالجة سداد الفاتورة واقتطاع المعاملة الحية 2026 ---
    on<ProcessOrderPaymentEvent>((event, emit) async {
      emit(CustomerOrderLoadingState());
      final result = await processOrderPaymentUseCase.call(
        payment: event.payment,
      );
      result.fold(
        (failure) =>
            emit(CustomerOrderFailureState(errorMessage: failure.message)),
        (_) => emit(ProcessOrderPaymentSuccessState()),
      );
    });
  }
}
