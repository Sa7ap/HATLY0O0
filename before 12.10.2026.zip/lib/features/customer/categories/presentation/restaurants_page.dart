import 'package:flutter/material.dart';

import '../../../../core/shared_widgets/persistent_cart_bar.dart'; // استدعاء الشريط العائم
import 'product_detail_page.dart';

class RestaurantsPage extends StatelessWidget {
  const RestaurantsPage({super.key});

  @override
  Widget build(BuildContext context) {
    final List<Map<String, dynamic>> mockMeals = [
      {
        'name': 'وجبة سوبر كومبو حار 🍔🔥',
        'price': 135.0,
        'desc': 'قطعتين دجاج مقرمش كبير، بطاطس حلزونية، صوص الجبن السائل، ولتر كولا بارد.',
      },
      {
        'name': 'بيتزا تشيكن رانش عائلية 🍕',
        'price': 190.0,
        'desc': 'عجينة إيطالية خفيفة، قطع دجاج مشوي، صوص الرانش السري، وموتزاريلا طبيعية.',
      },
    ];

    return Scaffold(
      backgroundColor: const Color(0xFFF8F9FA),
      appBar: AppBar(
        title: const Text(
          'المطاعم والوجبات 🍔',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            color: Colors.black87,
            fontFamily: 'Cairo',
            fontSize: 15,
          ),
        ),
        centerTitle: true,
        backgroundColor: Colors.white,
        elevation: 0.5,
        leading: IconButton(
          icon: const Icon(
            Icons.arrow_back_ios_new_rounded,
            color: Colors.black87,
            size: 20,
          ),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      // إدراج وحقن شريط السلة العائم المستمر لتحديث تجربة المستخدم حياً
      bottomNavigationBar: const PersistentCartBar(),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: mockMeals.length,
        itemBuilder: (context, index) {
          final meal = mockMeals[index];
          return Card(
            color: Colors.white,
            margin: const EdgeInsets.only(bottom: 14),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(14),
            ),
            elevation: 0,
            child: ListTile(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => ProductDetailPage(
                      productName: meal['name'],
                      productPrice: meal['price'],
                      productDescription: meal['desc'],
                    ),
                  ),
                );
              },
              contentPadding: const EdgeInsets.all(12),
              leading: Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: Colors.deepOrange.withValues(alpha: 0.06),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const Icon(
                  Icons.fastfood_rounded,
                  color: Colors.deepOrange,
                  size: 24,
                ),
              ),
              title: Text(
                meal['name'],
                style: const TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Cairo',
                ),
              ),
              subtitle: Text(
                '${meal['price'].toStringAsFixed(0)} ج.م',
                style: const TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.bold,
                  color: Colors.deepOrange,
                  fontFamily: 'Cairo',
                ),
              ),
              trailing: const Icon(
                Icons.arrow_forward_ios_rounded,
                size: 14,
                color: Colors.grey,
              ),
            ),
          );
        },
      ),
    );
  }
}
