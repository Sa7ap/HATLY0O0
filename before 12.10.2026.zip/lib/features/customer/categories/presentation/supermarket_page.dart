import 'package:flutter/material.dart';

import '../../../../core/shared_widgets/persistent_cart_bar.dart'; // استدعاء الشريط العائم الموحد
import 'product_detail_page.dart';

class SupermarketPage extends StatelessWidget {
  const SupermarketPage({super.key});

  @override
  Widget build(BuildContext context) {
    final List<Map<String, dynamic>> mockItems = [
      {
        'name': 'عبوة زيت عباد الشمس ١ لتر 🌻',
        'price': 95.0,
        'desc': 'زيت نقي ١٠٪ ومناسب لكافة الأغراض والطهي الصحي، خالي من الكوليسترول.',
      },
      {
        'name': 'قهوة سريعة التحضير ٢٠٠ جرام ☕',
        'price': 140.0,
        'desc': 'بن برازيلي مجفف بالتبريد ذو نكهة غنية ورائحة نفاذة، تحضر في ثوانٍ معدودة.',
      },
    ];

    return Scaffold(
      backgroundColor: const Color(0xFFF8F9FA),
      appBar: AppBar(
        title: const Text(
          'السوبرماركت والمقاضي 🛒',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            color: Colors.black87,
            fontFamily: 'Cairo',
            fontSize: 15,
          ),
        ),
        centerTitle: true,
        backgroundColor: Colors.white,
        elevation: 0.5,
        leading: IconButton(
          icon: const Icon(
            Icons.arrow_back_ios_new_rounded,
            color: Colors.black87,
            size: 20,
          ),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      // حقن شريط السلة السفلي المستمر
      bottomNavigationBar: const PersistentCartBar(),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: mockItems.length,
        itemBuilder: (context, index) {
          final item = mockItems[index];
          return Card(
            color: Colors.white,
            margin: const EdgeInsets.only(bottom: 14),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(14),
            ),
            elevation: 0,
            child: ListTile(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => ProductDetailPage(
                      productName: item['name'],
                      productPrice: item['price'],
                      productDescription: item['desc'],
                    ),
                  ),
                );
              },
              contentPadding: const EdgeInsets.all(12),
              leading: Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: Colors.blue.withValues(alpha: 0.06),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const Icon(
                  Icons.shopping_cart_rounded,
                  color: Colors.blue,
                  size: 24,
                ),
              ),
              title: Text(
                item['name'],
                style: const TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Cairo',
                ),
              ),
              subtitle: Text(
                '${item['price'].toStringAsFixed(0)} ج.م',
                style: const TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.bold,
                  color: Colors.blue,
                  fontFamily: 'Cairo',
                ),
              ),
              trailing: const Icon(
                Icons.arrow_forward_ios_rounded,
                size: 14,
                color: Colors.grey,
              ),
            ),
          );
        },
      ),
    );
  }
}
