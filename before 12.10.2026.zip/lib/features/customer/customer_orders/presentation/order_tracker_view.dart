import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import 'bloc/customer_order_bloc.dart';
import 'bloc/customer_order_event.dart';
import 'bloc/customer_order_state.dart';

class OrderTrackerView extends StatefulWidget {
  final String orderId;

  const OrderTrackerView({super.key, required this.orderId});

  @override
  State<OrderTrackerView> createState() => _OrderTrackerViewState();
}

class _OrderTrackerViewState extends State<OrderTrackerView> {
  @override
  void initState() {
    super.initState();
    // ١. إطلاق حدث بدء واستمرار التتبع الجغرافي الحي لحركة الكابتن فور فتح الشاشة
    context.read<CustomerOrderBloc>().add(
      StartOrderTrackingEvent(orderId: widget.orderId),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF8F9FA),
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0.5,
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'تتبع حركة الكابتن 📍',
              style: const TextStyle(
                fontSize: 15,
                fontWeight: FontWeight.bold,
                color: Colors.black87,
                fontFamily: 'Cairo',
              ),
            ),
            Text(
              'طلب رقم: #${widget.orderId}',
              style: const TextStyle(
                fontSize: 11,
                color: Colors.grey,
                fontFamily: 'Cairo',
              ),
            ),
          ],
        ),
        centerTitle: false,
        leading: IconButton(
          icon: const Icon(
            Icons.arrow_back_ios_new_rounded,
            color: Colors.black87,
            size: 20,
          ),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      // سيتم بناء الخريطة التفاعلية والـ BlocBuilder في الجزء الثاني...
      body: SafeArea(
        child: BlocBuilder<CustomerOrderBloc, CustomerOrderState>(
          builder: (context, state) {
            String currentStage = '1';
            double lat = 30.9575;
            double lng = 31.2594;

            // 3. استخراج بيانات الموقع الجغرافي والمرحلة الحالية فور نجاح التتبع
            if (state is GetOrderTrackingSuccessState) {
              currentStage = state.currentStage;
              lat = state.captainLatitude;
              lng = state.captainLongitude;
            }

            if (state is CustomerOrderLoadingState && currentStage == '1') {
              return const Center(
                child: CircularProgressIndicator(color: Colors.green),
              );
            }

            return Column(
              children: [
                // 4. لوحة محاكاة الخريطة الجغرافية الحية لحركة الكابتن
                Expanded(
                  flex: 4,
                  child: Container(
                    margin: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(
                        color: Colors.grey.withValues(alpha: 0.15),
                        width: 1,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withValues(alpha: 0.02),
                          blurRadius: 10,
                          offset: const Offset(0, 4),
                        ),
                      ],
                    ),
                    child: Stack(
                      children: [
                        // خلفية جغرافية تعبيرية تمثل الخريطة الحية
                        ClipRRect(
                          borderRadius: BorderRadius.circular(20),
                          child: Container(
                            color: const Color(0xFFEAECEE),
                            width: double.infinity,
                            height: double.infinity,
                            child: CustomPaint(painter: GridPainter()),
                          ),
                        ),
                        // مؤشر العميل (نقطة ثابتة)
                        const Positioned(
                          top: 80,
                          right: 100,
                          child: Column(
                            children: [
                              Icon(
                                Icons.home_filled,
                                color: Colors.deepOrange,
                                size: 36,
                              ),
                              Text(
                                'موقعك 🏠',
                                style: TextStyle(
                                  fontFamily: 'Cairo',
                                  fontSize: 11,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ],
                          ),
                        ),
                        // مؤشر الكابتن (نقطة حركية ديناميكية مبنية على الإحداثيات الممررة)
                        Positioned(
                          bottom: 100,
                          left: 120,
                          child: Column(
                            children: [
                              const Icon(
                                Icons.delivery_dining_rounded,
                                color: Colors.green,
                                size: 38,
                              ),
                              Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 8,
                                  vertical: 4,
                                ),
                                decoration: BoxDecoration(
                                  color: Colors.green,
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: Text(
                                  'الكابتن يتحرك: [${lat.toStringAsFixed(3)}, ${lng.toStringAsFixed(3)}]',
                                  style: const TextStyle(
                                    fontFamily: 'Cairo',
                                    fontSize: 9,
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                // سيتم استدعاء شريط المراحل السبعة والودجات المساعدة في الجزء الثالث كلياً...
                // 5. لوحة عرض مراحل التوصيل السبعة حركياً أسفل الشاشة
                Expanded(
                  flex: 3,
                  child: Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: const BorderRadius.only(
                        topLeft: Radius.circular(24),
                        topRight: Radius.circular(24),
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withValues(alpha: 0.04),
                          blurRadius: 12,
                          offset: const Offset(0, -4),
                        ),
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'مراحل خط سير التوصيل المعتمدة:',
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Cairo',
                            color: Colors.black87,
                          ),
                        ),
                        const SizedBox(height: 16),

                        // محاكاة بصرية تفاعلية للمرحلة الرابعة (جاري التوصيل للمنزل) من أصل ٧ مراحل
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            _buildStageDot(
                              context,
                              '1',
                              int.parse(currentStage) >= 1,
                              'قبول الطلب',
                            ),
                            _buildStageLine(int.parse(currentStage) >= 2),
                            _buildStageDot(
                              context,
                              '2',
                              int.parse(currentStage) >= 2,
                              'في المتجر',
                            ),
                            _buildStageLine(int.parse(currentStage) >= 3),
                            _buildStageDot(
                              context,
                              '3',
                              int.parse(currentStage) >= 3,
                              'تجهيز السلع',
                            ),
                            _buildStageLine(int.parse(currentStage) >= 4),
                            _buildStageDot(
                              context,
                              '4',
                              int.parse(currentStage) >= 4,
                              'جاري التوصيل',
                            ),
                          ],
                        ),
                        const SizedBox(height: 20),

                        // عرض كارت تفاصيل حالة التحرك الجغرافي الحالية للكابتن
                        Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: Colors.green.withValues(alpha: 0.06),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: const Row(
                            children: [
                              Icon(
                                Icons.directions_bike_rounded,
                                color: Colors.green,
                                size: 22,
                              ),
                              SizedBox(width: 12),
                              Expanded(
                                child: Text(
                                  'الكابتن غادر متجر التحضير وهو الآن في طريقه إليك بسرعة ثابتة. يرجى تجهيز الهاتف لاستقبال الاتصال.',
                                  style: TextStyle(
                                    fontSize: 12,
                                    color: Colors.black87,
                                    fontFamily: 'Cairo',
                                    height: 1.4,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }

  // ودجت بناء دوائر مراحل التوصيل الرقمية
  Widget _buildStageDot(
    BuildContext context,
    String stageNum,
    bool isCompleted,
    String label,
  ) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 32,
          height: 32,
          decoration: BoxDecoration(
            color: isCompleted ? Colors.green : Colors.grey.withValues(alpha: 0.2),
            shape: BoxShape.circle,
            border: isCompleted
                ? Border.all(color: Colors.greenAccent, width: 2)
                : null,
          ),
          child: Center(
            child: isCompleted
                ? const Icon(Icons.check, color: Colors.white, size: 16)
                : Text(
                    stageNum,
                    style: const TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                      color: Colors.grey,
                      fontFamily: 'Cairo',
                    ),
                  ),
          ),
        ),
        const SizedBox(height: 6),
        Text(
          label,
          style: TextStyle(
            fontSize: 10,
            fontWeight: isCompleted ? FontWeight.bold : FontWeight.normal,
            color: isCompleted ? Colors.green : Colors.grey,
            fontFamily: 'Cairo',
          ),
        ),
      ],
    );
  }

  // ودجت بناء الخطوط الرابطة بين مراحل التوصيل
  Widget _buildStageLine(bool isCompleted) {
    return Expanded(
      child: Container(
        height: 3,
        color: isCompleted ? Colors.green : Colors.grey.withValues(alpha: 0.2),
        margin: const EdgeInsets.only(bottom: 16),
      ),
    );
  }
}

// كلاس الرسم المساعد لتصميم شبكة الخريطة الرقمية التعبيرية بنقاء كامل بـ 0 أخطاء
class GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.black.withValues(alpha: 0.04)
      ..strokeWidth = 1.0;

    const double step = 25.0;

    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
