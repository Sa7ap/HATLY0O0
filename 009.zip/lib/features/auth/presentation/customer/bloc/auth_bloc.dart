import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../domain/usecases/send_otp_usecase.dart';
import '../../../domain/usecases/verify_otp_usecase.dart';
import 'auth_event.dart';
import 'auth_state.dart';

class AuthBloc extends Bloc<AuthEvent, AuthState> {
  final SendOtpUseCase sendOtpUseCase;
  final VerifyOtpUseCase verifyOtpUseCase;

  AuthBloc({required this.sendOtpUseCase, required this.verifyOtpUseCase})
    : super(AuthInitialState()) {
    on<SendOtpEvent>((event, emit) async {
      emit(AuthLoadingState());
      await Future.delayed(const Duration(milliseconds: 500));
      emit(OtpSentSuccessState());
    });

    on<VerifyOtpEvent>((event, emit) async {
      emit(AuthLoadingState());
      await Future.delayed(const Duration(milliseconds: 500));
      emit(OtpVerifySuccessState());
    });

    // --- معالجة الحدث الجديد المضاف: تحديث الحماية البيومترية حياً لعام 2026 ---
    on<UpdateBiometricSecuritySettingsEvent>((event, emit) async {
      emit(AuthLoadingState());
      // محاكاة حفظ التكوين الجديد للأمان الحيوي بجهاز المستخدم
      await Future.delayed(const Duration(milliseconds: 300));
      emit(
        BiometricSecurityUpdatedState(securitySettings: event.securitySettings),
      );
    });
  }
}
