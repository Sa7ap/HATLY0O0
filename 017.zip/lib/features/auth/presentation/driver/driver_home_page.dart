import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import 'wallet_bloc/driver_wallet_bloc.dart';
import 'wallet_bloc/driver_wallet_event.dart';
import 'wallet_bloc/driver_wallet_state.dart';

class DriverHomePage extends StatefulWidget {
  const DriverHomePage({super.key});

  @override
  State<DriverHomePage> createState() => _DriverHomePageState();
}

class _DriverHomePageState extends State<DriverHomePage> {
  @override
  void initState() {
    super.initState();
    // إطلاق حدث تحديث العدادات والأرباح التراكمية للكابتن فور فتح الشاشة
    context.read<DriverWalletBloc>().add(
      const RefreshDriverWalletBalancesEvent(driverId: 'driver_amr'),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF8F9FA),
      appBar: AppBar(
        title: const Text(
          'لوحة تحكم الكابتن 🚴',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            color: Colors.black87,
            fontFamily: 'Cairo',
            fontSize: 14,
          ),
        ),
        centerTitle: true,
        backgroundColor: Colors.white,
        elevation: 0.5,
        automaticallyImplyLeading: false, // الشاشة الرئيسية للـ Driver
      ),
      body: SafeArea(
        child: BlocConsumer<DriverWalletBloc, DriverWalletState>(
          listener: (context, state) {
            if (state is DriverWalletBalancesLoadedState) {
              debugPrint('--- [منظومة الكابتن الحية 2026] ---');
              debugPrint(
                'تم تحديث أرباح المحفظة الفورية للكابتن: ${state.totalEarnings} ج.م',
              );
            }
          },
          builder: (context, state) {
            double earnings = 0.0;
            String shiftInfo = 'جاري قراءة بيانات الوردية...';

            if (state is DriverWalletBalancesLoadedState) {
              earnings = state.totalEarnings;
              if (state.activeShifts.isNotEmpty) {
                // تصحيح: استدعاء الخواص البديلة المعتمدة بكيان الوردية لمشروعك الحقيقي
                shiftInfo =
                    '${state.activeShifts.first.orderSummary} (${state.activeShifts.first.distance})';
              }
            }

            return Padding(
              padding: const EdgeInsets.all(20.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  // 1. لوحة عرض ومحاكاة رصيد محفظة المندوب التراكمية حياً
                  Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: const Color(
                        0xFF1B5E20,
                      ), // اللون الأخضر الداكن الخاص بالكباتن
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withValues(alpha: 0.04),
                          blurRadius: 10,
                        ),
                      ],
                    ),
                    child: Column(
                      children: [
                        const Icon(
                          Icons.account_balance_wallet_rounded,
                          color: Colors.white70,
                          size: 36,
                        ),
                        const SizedBox(height: 10),
                        const Text(
                          'إجمالي أرباحك التراكمية الحالية:',
                          style: TextStyle(
                            fontFamily: 'Cairo',
                            fontSize: 11,
                            color: Colors.white70,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          '${earnings.toStringAsFixed(0)} ج.م',
                          style: const TextStyle(
                            fontFamily: 'Cairo',
                            fontSize: 26,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 20),

                  // 2. بطاقة قراءة النطاق الجغرافي والوردية الحية
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: Colors.grey.withValues(alpha: 0.06)),
                    ),
                    child: Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: Colors.orange.withValues(alpha: 0.08),
                            shape: BoxShape.circle,
                          ),
                          child: const Icon(
                            Icons.explore_rounded,
                            color: Colors.orange,
                            size: 22,
                          ),
                        ),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                'الوردية والنطاق النشط حالياً:',
                                style: TextStyle(
                                  fontSize: 11,
                                  color: Colors.grey,
                                  fontFamily: 'Cairo',
                                ),
                              ),
                              const SizedBox(height: 2),
                              Text(
                                shiftInfo,
                                style: const TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.bold,
                                  fontFamily: 'Cairo',
                                  color: Colors.black87,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 24),

                  // 3. قائمة استقبال طلبات التوصيل الفورية للعملاء
                  const Text(
                    'الطلبات الجارية بمحيطك الجغرافي:',
                    style: TextStyle(
                      fontFamily: 'Cairo',
                      fontSize: 13,
                      fontWeight: FontWeight.bold,
                      color: Colors.black87,
                    ),
                  ),
                  const SizedBox(height: 12),
                  Expanded(
                    child: state is DriverWalletLoadingState
                        ? const Center(
                            child: CircularProgressIndicator(
                              color: Color(0xFF1B5E20),
                            ),
                          )
                        : Container(
                            padding: const EdgeInsets.all(20),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(16),
                              border: Border.all(
                                color: Colors.grey.withValues(alpha: 0.06),
                              ),
                            ),
                            child: const Center(
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(
                                    Icons.directions_bike_rounded,
                                    color: Colors.grey,
                                    size: 40,
                                  ),
                                  SizedBox(height: 12),
                                  Text(
                                    'في انتظار بث المطبخ لـ جاهزية الوجبة... 🧑‍🍳',
                                    style: TextStyle(
                                      fontFamily: 'Cairo',
                                      fontSize: 12,
                                      color: Colors.grey,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}
