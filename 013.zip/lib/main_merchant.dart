// lib/main_merchant.dart
import 'package:flutter/material.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MerchantApp());
}

class MerchantApp extends StatelessWidget {
  const MerchantApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'هاتلي - التاجر',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.purple, // ثيم مخصص ومختلف للتاجر (اللون البنفسجي) لضمان الفصل البصري الكامل
        fontFamily: 'Cairo',
      ),
      home: const Scaffold(
        body: Center(
          child: Text(
            'واجهة لوحة تحكم التاجر وصاحب المحل 🏪\nجاري تهيئة قائمة المنتجات وإدارة الطلبات الواردة...',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: Colors.purple,
            ),
          ),
        ),
      ),
    );
  }
}
