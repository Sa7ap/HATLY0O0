import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import 'core/utils/service_locator.dart';
import 'core/welcome_page.dart';
import 'features/auth/presentation/customer/bloc/auth_bloc.dart';
import 'features/auth/presentation/driver/bloc/driver_auth_bloc.dart';
import 'features/auth/presentation/merchant/bloc/merchant_auth_bloc.dart';
import 'features/auth/presentation/merchant/product_bloc/merchant_product_bloc.dart';
import 'features/customer/customer_orders/presentation/bloc/customer_order_bloc.dart';
import 'features/customer/wallet/presentation/bloc/wallet_bloc.dart';
// استيراد الـ Bloc الجديد الخاص بمحفظة وأرباح المندوب التراكمية
import 'features/auth/presentation/driver/wallet_bloc/driver_wallet_bloc.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // تشغيل حاوية حقن التبعيات المركزية لجميع الأطراف
  await initServiceLocator();

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider<AuthBloc>(create: (context) => sl<AuthBloc>()),
        BlocProvider<DriverAuthBloc>(create: (context) => sl<DriverAuthBloc>()),
        BlocProvider<MerchantAuthBloc>(
          create: (context) => sl<MerchantAuthBloc>(),
        ),
        BlocProvider<MerchantProductBloc>(
          create: (context) => sl<MerchantProductBloc>(),
        ),
        BlocProvider<CustomerOrderBloc>(
          create: (context) => sl<CustomerOrderBloc>(),
        ),
        BlocProvider<WalletBloc>(create: (context) => sl<WalletBloc>()),
        // حقن وتوفير محرك محفظة وأرباح المندوب التراكمية الجديد هنا بنجاح
        BlocProvider<DriverWalletBloc>(
          create: (context) => sl<DriverWalletBloc>(),
        ),
      ],
      child: MaterialApp(
        title: 'تطبيق توصيل الطلبات',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          primarySwatch: Colors.deepOrange,
          primaryColor: Colors.deepOrange,
          fontFamily: 'Cairo',
        ),
        home: const WelcomePage(),
      ),
    );
  }
}
