import 'package:equatable/equatable.dart';

class PaymentEntity extends Equatable {
  final String transactionId; // المعرف الفريد لعملية الدفع الرقمية
  final String orderId; // كود الطلب الحر المستهدف سداده
  final String paymentMethod; // طريقة السداد (مثال: 'CASH' أو 'WALLET')
  final double amountPaid; // المبلغ الإجمالي الصافي المستقطع بالفاتورة
  final String
  paymentStatus; // حالة السداد الحالية (مثال: 'PENDING', 'SUCCESS')

  const PaymentEntity({
    required this.transactionId,
    required this.orderId,
    required this.paymentMethod,
    required this.amountPaid,
    required this.paymentStatus,
  });

  @override
  List<Object?> get props => [
    transactionId,
    orderId,
    paymentMethod,
    amountPaid,
    paymentStatus,
  ];
}
