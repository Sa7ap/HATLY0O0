import 'package:dartz/dartz.dart';
import 'package:hatlyai/core/errors/failures.dart';

import '../../data/datasources/order_remote_data_source.dart';
import '../../data/models/message_model.dart';
import '../../data/models/payment_model.dart';
import '../../domain/entities/order_entity.dart';
import '../../domain/entities/notification_entity.dart';
import '../../domain/entities/evaluation_entity.dart';
import '../../domain/entities/past_order_entity.dart';
import '../../domain/entities/message_entity.dart';
import '../../domain/entities/address_entity.dart';
import '../../domain/entities/payment_entity.dart';
import '../../domain/repositories/order_repository.dart';

class OrderRepositoryImpl implements OrderRepository {
  final OrderRemoteDataSource remoteDataSource;

  OrderRepositoryImpl({required this.remoteDataSource});

  @override
  Future<Either<Failure, void>> createOrder(OrderEntity order) async =>
      const Right(null);

  @override
  Future<Either<Failure, void>> updateOrderStatus(
    String orderId,
    String status,
  ) async => const Right(null);

  @override
  Future<Either<Failure, List<NotificationEntity>>> getNotifications() async =>
      const Right([]);

  @override
  Future<Either<Failure, void>> submitOrderEvaluation(
    EvaluationEntity evaluation,
  ) async => const Right(null);

  @override
  Future<Either<Failure, List<PastOrderEntity>>> getOrderHistory() async =>
      const Right([]);

  @override
  Future<Either<Failure, List<AddressEntity>>> getSavedAddresses() async =>
      const Right([]);

  @override
  Future<Either<Failure, void>> saveNewAddress(AddressEntity address) async =>
      const Right(null);

  @override
  Future<Either<Failure, void>> updateCustomerProfile({
    required String name,
    required String phone,
  }) async => const Right(null);

  @override
  Future<Either<Failure, void>> processOrderPayment({
    required PaymentEntity payment,
  }) async => const Right(null);

  @override
  Future<Either<Failure, PaymentEntity>> getPaymentReceiptDetail({
    required String orderId,
  }) async {
    return Right(
      PaymentModel(
        transactionId: 'TXN',
        orderId: orderId,
        paymentMethod: 'WALLET',
        amountPaid: 0.0,
        paymentStatus: 'SUCCESS',
      ),
    );
  }

  // --- الدالات الجديدة المضافة: محاكاة غرف الشات والمحادثة الفورية للتوصيل ---
  @override
  Future<Either<Failure, List<MessageEntity>>> getChatMessages(
    String orderId,
  ) async {
    try {
      await Future.delayed(const Duration(milliseconds: 400));
      final List<MessageModel> mockMessages = [
        const MessageModel(
          messageId: 'msg_1',
          senderId: 'driver',
          text: 'السلام عليكم يا فندم، أنا استلمت الطلب الحر من المتجر وتحركت الآن 🚴',
          timestamp: '12:55 م',
        ),
        const MessageModel(
          messageId: 'msg_2',
          senderId: 'customer',
          text: 'وعليكم السلام يا كابتن، تمام أنا منتظرك أمام صيدلية الأمانة في شارع بورسعيد 🏠',
          timestamp: '12:56 م',
        ),
      ];
      return Right(mockMessages);
    } catch (e) {
      return Left(ServerFailure(e.toString()));
    }
  }

  @override
  Future<Either<Failure, void>> sendChatMessage(
    String orderId,
    MessageEntity message,
  ) async {
    try {
      await Future.delayed(const Duration(milliseconds: 200));
      return const Right(null);
    } catch (e) {
      return Left(ServerFailure(e.toString()));
    }
  }
}
