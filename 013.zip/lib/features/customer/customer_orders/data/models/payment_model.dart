import '../../domain/entities/payment_entity.dart';

class PaymentModel extends PaymentEntity {
  const PaymentModel({
    required super.transactionId,
    required super.orderId,
    required super.paymentMethod,
    required super.amountPaid,
    required super.paymentStatus,
  });

  // دالة جلب وقراءة بيانات وتأكيدات الدفع الواردة من خوادم الشبكة
  factory PaymentModel.fromJson(Map<String, dynamic> json) {
    return PaymentModel(
      transactionId: json['transaction_id'] as String? ?? '',
      orderId: json['order_id'] as String? ?? '',
      paymentMethod: json['payment_method'] as String? ?? 'CASH',
      amountPaid: (json['amount_paid'] as num? ?? 0.0).toDouble(),
      paymentStatus: json['payment_status'] as String? ?? 'PENDING',
    );
  }

  // دالة تحويل كائن السداد إلى خريطة Map JSON للضخ داخل قواعد البيانات
  Map<String, dynamic> toJson() {
    return {
      'transaction_id': transactionId,
      'order_id': orderId,
      'payment_method': paymentMethod,
      'amount_paid': amountPaid,
      'payment_status': paymentStatus,
    };
  }
}
