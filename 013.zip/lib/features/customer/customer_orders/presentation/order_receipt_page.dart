import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import 'bloc/customer_order_bloc.dart';
import 'bloc/customer_order_event.dart';
import 'bloc/customer_order_state.dart';
import '../domain/entities/payment_entity.dart';

class OrderReceiptPage extends StatefulWidget {
  final String orderId;

  const OrderReceiptPage({super.key, required this.orderId});

  @override
  State<OrderReceiptPage> createState() => _OrderReceiptPageState();
}

class _OrderReceiptPageState extends State<OrderReceiptPage> {
  @override
  void initState() {
    super.initState();
    // إطلاق حدث استدعاء الإيصال الرقمي للطلب فور فتح الشاشة
    context.read<CustomerOrderBloc>().add(
      GetPaymentReceiptDetailEvent(orderId: widget.orderId),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF8F9FA),
      appBar: AppBar(
        title: const Text(
          'إيصال الدفع الرقمي 🧾',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            color: Colors.black87,
            fontFamily: 'Cairo',
            fontSize: 15,
          ),
        ),
        centerTitle: true,
        backgroundColor: Colors.white,
        elevation: 0.5,
        automaticallyImplyLeading:
            false, // إجبار التفاعل مع أزرار الإغلاق السفلية بنقاء
      ),
      // يتبع مباشرة وتلقائياً الجزء 2 من 2 بالرد القادم...
      body: SafeArea(
        child: BlocBuilder<CustomerOrderBloc, CustomerOrderState>(
          builder: (context, state) {
            PaymentEntity? receipt;

            if (state is GetPaymentReceiptDetailSuccessState) {
              receipt = state.receipt;
            }

            if (state is CustomerOrderLoadingState && receipt == null) {
              return const Center(
                child: CircularProgressIndicator(color: Colors.deepOrange),
              );
            }

            if (receipt == null) {
              return const Center(
                child: Text(
                  'فشل في تحميل تفاصيل الإيصال المالي.',
                  style: TextStyle(
                    fontFamily: 'Cairo',
                    fontSize: 13,
                    color: Colors.grey,
                  ),
                ),
              );
            }

            return Padding(
              padding: const EdgeInsets.all(24.0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  // بطاقة الفاتورة الرقمية الأنيقة
                  Container(
                    padding: const EdgeInsets.all(24),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(20),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.03),
                          blurRadius: 15,
                          offset: const Offset(0, 8),
                        ),
                      ],
                    ),
                    child: Column(
                      children: [
                        const Icon(
                          Icons.check_circle_rounded,
                          color: Colors.green,
                          size: 56,
                        ),
                        const SizedBox(height: 14),
                        const Text(
                          'عملية دفع ناجحة ✅',
                          style: TextStyle(
                            fontFamily: 'Cairo',
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: Colors.green,
                          ),
                        ),
                        const SizedBox(height: 24),

                        _buildReceiptRow(
                          label: 'رقم المعاملة المالية:',
                          value: receipt.transactionId,
                        ),
                        _buildReceiptRow(
                          label: 'كود الطلب الملحق:',
                          value: '#${receipt.orderId}',
                        ),
                        _buildReceiptRow(
                          label: 'طريقة السداد المعتمدة:',
                          value: receipt.paymentMethod == 'WALLET'
                              ? 'رصيد المحفظة 📱'
                              : 'نقداً كاش 💵',
                        ),
                        const Divider(height: 32, thickness: 0.8),
                        _buildReceiptRow(
                          label: 'المبلغ الإجمالي المستقطع:',
                          value: '${receipt.amountPaid.toStringAsFixed(0)} ج.م',
                          isTotal: true,
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 40),

                  // زر العودة والإنهاء لغلق الرحلة المالية بنقاء
                  ElevatedButton(
                    onPressed: () {
                      Navigator.of(context).popUntil((route) => route.isFirst);
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.black87,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      elevation: 0,
                    ),
                    child: const Text(
                      'الخروج والعودة للرئيسية',
                      style: TextStyle(
                        fontFamily: 'Cairo',
                        fontWeight: FontWeight.bold,
                        fontSize: 13,
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }

  // ودجت بناء وتنسيق صفوف تفاصيل الإيصال الرقمي بنقاء 100%
  Widget _buildReceiptRow({
    required String label,
    required String value,
    bool isTotal = false,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: TextStyle(
              fontFamily: 'Cairo',
              fontSize: isTotal ? 13 : 11,
              color: isTotal ? Colors.black87 : Colors.grey,
              fontWeight: isTotal ? FontWeight.bold : FontWeight.normal,
            ),
          ),
          Text(
            value,
            style: TextStyle(
              fontFamily: 'Cairo',
              fontSize: isTotal ? 16 : 11,
              color: isTotal ? Colors.green : Colors.black87,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }
}
