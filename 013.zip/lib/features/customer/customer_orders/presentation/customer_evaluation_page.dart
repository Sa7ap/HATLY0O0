import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import 'bloc/customer_order_bloc.dart';
import 'bloc/customer_order_event.dart';
import 'bloc/customer_order_state.dart';
import '../domain/entities/evaluation_entity.dart';

class CustomerEvaluationPage extends StatefulWidget {
  final String orderId;

  const CustomerEvaluationPage({super.key, required this.orderId});

  @override
  State<CustomerEvaluationPage> createState() => _CustomerEvaluationPageState();
}

class _CustomerEvaluationPageState extends State<CustomerEvaluationPage> {
  double _driverRating = 5.0; // عدد النجمات الافتراضي لتقييم المندوب
  double _merchantRating = 5.0; // عدد النجمات الافتراضي لتقييم المتجر/المطبخ
  final TextEditingController _commentController = TextEditingController();

  @override
  void dispose() {
    _commentController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF8F9FA),
      appBar: AppBar(
        title: const Text(
          'تقييم جودة الخدمة ⭐',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            color: Colors.black87,
            fontFamily: 'Cairo',
            fontSize: 16,
          ),
        ),
        centerTitle: true,
        backgroundColor: Colors.white,
        elevation: 0.5,
        automaticallyImplyLeading:
            false, // منع العودة للخلف لإجبار إغلاق المعاملة بنقاء
      ),
      // سيتم استدعاء الـ BlocConsumer وبناء النجمات الذهبية وأزرار الحفظ بالأسفل في الجزء الثاني...
      body: SafeArea(
        child: BlocConsumer<CustomerOrderBloc, CustomerOrderState>(
          listener: (context, state) {
            // الاستماع لحالة نجاح حفظ التقييم والنجمات في السيرفر لإغلاق الرحلة وتوجيه العميل للرئيسية
            if (state is SubmitOrderEvaluationSuccessState) {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text(
                    'شكراً لك! تم حفظ تقييمك وملاحظاتك بنجاح لتحسين جودة الخدمة. ❤️🌟',
                  ),
                  backgroundColor: Colors.green,
                ),
              );
              // تفريغ المكدس والعودة لصفحة التطبيق الرئيسية بنقاء كلي بنظام الـ Clean Architecture
              Navigator.of(context).popUntil((route) => route.isFirst);
            } else if (state is CustomerOrderFailureState) {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text(state.errorMessage),
                  backgroundColor: Colors.red,
                ),
              );
            }
          },
          builder: (context, state) {
            return SingleChildScrollView(
              padding: const EdgeInsets.all(20.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  // رسالة ترحيبية علوية بنظام الرقابة والجودة
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.green.withOpacity(0.05),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Column(
                      children: [
                        const Icon(
                          Icons.stars_rounded,
                          color: Colors.green,
                          size: 48,
                        ),
                        const SizedBox(height: 12),
                        const Text(
                          'تم توصيل طلبك بنجاح! 🏁',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Cairo',
                            color: Colors.black87,
                          ),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          'رأيك يهمنا جداً لتطوير بوابات هاتلي لعام 2026 وضمان أرقى تجارب التوصيل والمطابخ.',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontSize: 12,
                            color: Colors.grey[700],
                            fontFamily: 'Cairo',
                            height: 1.5,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 28),

                  // ١. قسم تقييم الكابتن والمندوب الجغرافي
                  const Text(
                    'ما هو تقييمك لأداء كابتن التوصيل؟ ⭐',
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Cairo',
                      color: Colors.black87,
                    ),
                  ),
                  const SizedBox(height: 10),
                  _buildRatingStarsBar(
                    currentRating: _driverRating,
                    onRatingChanged: (newRating) {
                      setState(() {
                        _driverRating = newRating;
                      });
                    },
                  ),
                  const SizedBox(height: 28),

                  // ٢. قسم تقييم متجر التاجر والمطبخ
                  const Text(
                    'ما هو تقييمك لجودة المتجر وتجهيز السلع؟ 🍔',
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Cairo',
                      color: Colors.black87,
                    ),
                  ),
                  const SizedBox(height: 10),
                  _buildRatingStarsBar(
                    currentRating: _merchantRating,
                    onRatingChanged: (newRating) {
                      setState(() {
                        _merchantRating = newRating;
                      });
                    },
                  ),
                  const SizedBox(height: 28),

                  // ٣. حقل كتابة الملاحظات والشكاوى النصية للعميل
                  const Text(
                    'اكتب ملاحظاتك أو شكواك هنا (اختياري):',
                    style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Cairo',
                      color: Colors.black54,
                    ),
                  ),
                  const SizedBox(height: 10),
                  TextField(
                    controller: _commentController,
                    maxLines: 3,
                    style: const TextStyle(fontSize: 13, fontFamily: 'Cairo'),
                    decoration: InputDecoration(
                      hintText:
                          'مثال: التوصيل سريع جداً والوجبة ساخنة وممتازة...',
                      hintStyle: const TextStyle(
                        color: Colors.grey,
                        fontSize: 12,
                        fontFamily: 'Cairo',
                      ),
                      filled: true,
                      fillColor: Colors.white,
                      contentPadding: const EdgeInsets.all(14),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: BorderSide(
                          color: Colors.grey.withOpacity(0.1),
                        ),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: BorderSide(
                          color: Colors.grey.withOpacity(0.1),
                        ),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: const BorderSide(color: Colors.green),
                      ),
                    ),
                  ),
                  const SizedBox(height: 36),

                  // زر الحفظ والإرسال المباشر التفاعلي
                  ElevatedButton(
                    onPressed: state is CustomerOrderLoadingState
                        ? null
                        : () {
                            // تجميع كتل البيانات وضخ الكيان التجريدي للـ Bloc بنقاء كامل
                            final evaluation = EvaluationEntity(
                              orderId: widget.orderId,
                              driverRating: _driverRating,
                              merchantRating: _merchantRating,
                              comment: _commentController.text.trim(),
                            );

                            context.read<CustomerOrderBloc>().add(
                              SubmitOrderEvaluationEvent(
                                evaluation: evaluation,
                              ),
                            );
                          },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.green,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      elevation: 0,
                    ),
                    child: state is CustomerOrderLoadingState
                        ? const SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(
                              color: Colors.white,
                              strokeWidth: 2,
                            ),
                          )
                        : const Text(
                            'تثبيت وإرسال التقييم النهائي',
                            style: TextStyle(
                              fontFamily: 'Cairo',
                              fontSize: 14,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }

  // ودجت بناء شريط النجمات الخمس الذهبية التفاعلية آلياً
  Widget _buildRatingStarsBar({
    required double currentRating,
    required Function(double) onRatingChanged,
  }) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: List.generate(5, (index) {
        final starValue = index + 1.0;
        return IconButton(
          onPressed: () => onRatingChanged(starValue),
          icon: Icon(
            starValue <= currentRating
                ? Icons.star_rounded
                : Icons.star_border_rounded,
            color: starValue <= currentRating ? Colors.amber : Colors.grey[400],
            size: 34,
          ),
        );
      }),
    );
  }
}
