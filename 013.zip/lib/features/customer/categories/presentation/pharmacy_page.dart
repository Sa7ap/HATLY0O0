import 'package:flutter/material.dart';

import '../../../../core/shared_widgets/persistent_cart_bar.dart'; // استدعاء الشريط العائم الموحد
import 'product_detail_page.dart';

class PharmacyPage extends StatelessWidget {
  const PharmacyPage({super.key});

  @override
  Widget build(BuildContext context) {
    final List<Map<String, dynamic>> mockProducts = [
      {
        'name': 'فيتامين سي فوار ١٠٠٠ مجم 🍊',
        'price': 75.0,
        'desc': 'مكمل غذائي سريع الامتصاص لدعم المناعة ومقاومة الإجهاد اليومي، عبوة تحتوي على ٢٠ قرصاً فواراً.',
      },
      {
        'name': 'جهاز قياس ضغط الدم الرقمي 🩺',
        'price': 650.0,
        'desc': 'جهاز إلكتروني دقيق بالكامل لقياس ضغط الدم ونبضات القلب من المعصم، مزود بذاكرة تخزين لشخصين.',
      },
    ];

    return Scaffold(
      backgroundColor: const Color(0xFFF8F9FA),
      appBar: AppBar(
        title: const Text(
          'الصيدلية والمستلزمات 🩺',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            color: Colors.black87,
            fontFamily: 'Cairo',
            fontSize: 15,
          ),
        ),
        centerTitle: true,
        backgroundColor: Colors.white,
        elevation: 0.5,
        leading: IconButton(
          icon: const Icon(
            Icons.arrow_back_ios_new_rounded,
            color: Colors.black87,
            size: 20,
          ),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      // حقن شريط السلة السفلي المستمر
      bottomNavigationBar: const PersistentCartBar(),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: mockProducts.length,
        itemBuilder: (context, index) {
          final product = mockProducts[index];
          return Card(
            color: Colors.white,
            margin: const EdgeInsets.only(bottom: 14),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(14),
            ),
            elevation: 0,
            child: ListTile(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => ProductDetailPage(
                      productName: product['name'],
                      productPrice: product['price'],
                      productDescription: product['desc'],
                    ),
                  ),
                );
              },
              contentPadding: const EdgeInsets.all(12),
              leading: Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: Colors.green.withOpacity(0.06),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const Icon(
                  Icons.local_pharmacy_rounded,
                  color: Colors.green,
                  size: 24,
                ),
              ),
              title: Text(
                product['name'],
                style: const TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Cairo',
                ),
              ),
              subtitle: Text(
                '${product['price'].toStringAsFixed(0)} ج.م',
                style: const TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.bold,
                  color: Colors.green,
                  fontFamily: 'Cairo',
                ),
              ),
              trailing: const Icon(
                Icons.arrow_forward_ios_rounded,
                size: 14,
                color: Colors.grey,
              ),
            ),
          );
        },
      ),
    );
  }
}
