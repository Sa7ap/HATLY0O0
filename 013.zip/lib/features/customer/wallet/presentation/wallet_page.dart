import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import 'bloc/wallet_bloc.dart';
import 'bloc/wallet_event.dart';
import 'bloc/wallet_state.dart';
import '../domain/entities/wallet_transaction_entity.dart';

class WalletPage extends StatefulWidget {
  const WalletPage({super.key});

  @override
  State<WalletPage> createState() => _WalletPageState();
}

class _WalletPageState extends State<WalletPage> {
  @override
  void initState() {
    super.initState();
    // إطلاق حدث جلب الرصيد وحدث جلب كشف حساب المعاملات الماليّة فوراً عند فتح الشاشة
    context.read<WalletBloc>().add(GetWalletBalanceEvent());
    context.read<WalletBloc>().add(GetWalletTransactionsEvent());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF8F9FA),
      appBar: AppBar(
        title: const Text(
          'محفظتي الإلكترونية 💳',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            color: Colors.black87,
            fontFamily: 'Cairo',
            fontSize: 16,
          ),
        ),
        centerTitle: true,
        backgroundColor: Colors.white,
        elevation: 0.5,
        leading: IconButton(
          icon: const Icon(
            Icons.arrow_back_ios_new_rounded,
            color: Colors.black87,
          ),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: SafeArea(
        child: BlocConsumer<WalletBloc, WalletState>(
          listener: (context, state) {
            // الاستماع لحالة الخطأ المالي الموثقة وعرض التنبيه
            if (state is WalletError) {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text(state.message),
                  backgroundColor: Colors.red,
                ),
              );
            }
          },
          builder: (context, state) {
            double currentBalance = 0.0;
            String currency = 'ج.م';
            List<WalletTransactionEntity> transactionsList = [];

            // 1. استخراج الرصيد والعملة الحقيقية فور تحميل المحفظة بنجاح
            if (state is WalletLoaded) {
              currentBalance = state.wallet.balance;
              currency = state.wallet.currency;
            }

            // 2. استخراج قائمة كشف الحساب المحدثة حركياً فور نجاح جلب المعاملات
            if (state is WalletTransactionsLoadedState) {
              transactionsList = state.transactions;
            }

            if (state is WalletLoading && currentBalance == 0.0) {
              return const Center(
                child: CircularProgressIndicator(color: Colors.deepOrange),
              );
            }

            return SingleChildScrollView(
              padding: const EdgeInsets.all(24.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  // شاشة كارت الرصيد والتحكم المالي المكتمل... يتبع في الجزء الثاني كلياً
                  // 3. كارت عرض الرصيد الإلكتروني الحالي للعميل
                  Container(
                    padding: const EdgeInsets.all(24),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [Colors.deepOrange, Colors.orangeAccent],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      borderRadius: BorderRadius.circular(20),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.deepOrange.withValues(alpha: 0.3),
                          blurRadius: 12,
                          offset: const Offset(0, 6),
                        ),
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'الرصيد المتاح:',
                          style: TextStyle(
                            color: Colors.white70,
                            fontSize: 13,
                            fontFamily: 'Cairo',
                          ),
                        ),
                        const SizedBox(height: 8),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.baseline,
                          textBaseline: TextBaseline.alphabetic,
                          children: [
                            Text(
                              currentBalance.toStringAsFixed(0),
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 32,
                                fontWeight: FontWeight.bold,
                                fontFamily: 'Cairo',
                              ),
                            ),
                            const SizedBox(width: 6),
                            Text(
                              currency,
                              style: const TextStyle(
                                color: Colors.white70,
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                                fontFamily: 'Cairo',
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 32),

                  // 4. خيارات الشحن المالي السريع للمحفظة المربوطة بالـ Bloc
                  const Text(
                    'شحن رصيد سريع:',
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Cairo',
                      color: Colors.black87,
                    ),
                  ),
                  const SizedBox(height: 12),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      _buildQuickQuickChargeButton(context, 50.0, '50+ ج.م'),
                      _buildQuickQuickChargeButton(context, 100.0, '100+ ج.م'),
                      _buildQuickQuickChargeButton(context, 200.0, '200+ ج.م'),
                    ],
                  ),
                  const SizedBox(height: 36),

                  // 5. قسم كشف حساب العمليات والحركات المالية التراكمية
                  const Text(
                    'كشف حساب المعاملات الأخيرة 📄',
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Cairo',
                      color: Colors.black87,
                    ),
                  ),
                  const SizedBox(height: 16),

                  // عرض رسالة بديلة إذا كان كشف الحساب فارغاً مؤقتاً
                  transactionsList.isEmpty
                      ? _buildEmptyTransactionsView()
                      : ListView.builder(
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          itemCount: transactionsList.length,
                          itemBuilder: (context, index) {
                            final tx = transactionsList[index];
                            return _buildTransactionRowItem(tx);
                          },
                        ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }

  // ودجت بناء أزرار شحن الرصيد السريع المطابق للـ Constructor في مشروعك
  Widget _buildQuickQuickChargeButton(
    BuildContext context,
    double amount,
    String label,
  ) {
    return Expanded(
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 4),
        height: 46,
        child: OutlinedButton(
          onPressed: () {
            // إطلاق حدث الشحن المالي الموضع الصائب مباشرة بدون أسماء معاملات
            context.read<WalletBloc>().add(UpdateWalletBalanceEvent(amount));
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text('جاري معالجة شحن مبلغ $amount ج.م... ⏳'),
                backgroundColor: Colors.black87,
              ),
            );
          },
          style: OutlinedButton.styleFrom(
            side: const BorderSide(color: Colors.deepOrange, width: 1),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            foregroundColor: Colors.deepOrange,
          ),
          child: Text(
            label,
            style: const TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.bold,
              fontFamily: 'Cairo',
            ),
          ),
        ),
      ),
    );
  }

  // ودجت تصميم كروت وحركات كشف الحساب (شحن / خصم) بنقاء كلي
  Widget _buildTransactionRowItem(WalletTransactionEntity tx) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: Colors.grey.withValues(alpha: 0.05),
          width: 1,
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: tx.isCredit
                  ? Colors.green.withValues(alpha: 0.08)
                  : Colors.red.withValues(alpha: 0.08),
              shape: BoxShape.circle,
            ),
            child: Icon(
              tx.isCredit
                  ? Icons.add_circle_outline_rounded
                  : Icons.remove_circle_outline_rounded,
              color: tx.isCredit ? Colors.green : Colors.red,
              size: 22,
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  tx.title,
                  style: const TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.bold,
                    color: Colors.black87,
                    fontFamily: 'Cairo',
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  tx.date,
                  style: const TextStyle(
                    fontSize: 11,
                    color: Colors.grey,
                    fontFamily: 'Cairo',
                  ),
                ),
              ],
            ),
          ),
          Text(
            '${tx.isCredit ? "+" : "-"}${tx.amount.toStringAsFixed(0)} ج.م',
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.bold,
              color: tx.isCredit ? Colors.green : Colors.red,
              fontFamily: 'Cairo',
            ),
          ),
        ],
      ),
    );
  }

  // واجهة عرض بديلة عند خلو المخزون المالي من الحركات
  Widget _buildEmptyTransactionsView() {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
      ),
      child: const Center(
        child: Text(
          'لا توجد معاملات مالية مسجلة حتى الآن.',
          style: TextStyle(
            fontFamily: 'Cairo',
            fontSize: 13,
            color: Colors.grey,
          ),
        ),
      ),
    );
  }
}
