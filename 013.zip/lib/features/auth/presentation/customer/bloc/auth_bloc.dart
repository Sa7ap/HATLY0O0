import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:shared_preferences/shared_preferences.dart'; // استدعاء الحزمة القياسية مباشرة لعام 2026

import '../../../domain/usecases/send_otp_usecase.dart';
import '../../../domain/usecases/verify_otp_usecase.dart';
import 'auth_event.dart';
import 'auth_state.dart';

class AuthBloc extends Bloc<AuthEvent, AuthState> {
  final SendOtpUseCase sendOtpUseCase;
  final VerifyOtpUseCase verifyOtpUseCase;
  final SharedPreferences
  sharedPreferences; // استخدام الحزمة القياسية مباشرة لحسم المشاكل

  AuthBloc({
    required this.sendOtpUseCase,
    required this.verifyOtpUseCase,
    required this.sharedPreferences,
  }) : super(AuthInitialState()) {
    on<SendOtpEvent>((event, emit) async {
      emit(AuthLoadingState());
      await Future.delayed(const Duration(milliseconds: 500));
      emit(OtpSentSuccessState());
    });

    on<VerifyOtpEvent>((event, emit) async {
      emit(AuthLoadingState());
      await Future.delayed(const Duration(milliseconds: 500));
      emit(OtpVerifySuccessState());
    });

    // --- معالجة الحدث: حفظ وتثبيت التكوين الأمني البيومتري محلياً على ذاكرة الجهاز لعام 2026 ---
    on<UpdateBiometricSecuritySettingsEvent>((event, emit) async {
      emit(AuthLoadingState());

      // استخدام الدالة القياسية المعتمدة بـ SharedPreferences لحفظ القيم بشكل دائم
      await sharedPreferences.setBool(
        'is_biometric_enabled',
        event.securitySettings.isBiometricEnabled,
      );
      await sharedPreferences.setBool(
        'is_2fa_enabled',
        event.securitySettings.isTwoFactorAuthEnabled,
      );

      emit(
        BiometricSecurityUpdatedState(securitySettings: event.securitySettings),
      );
    });
  }
}
