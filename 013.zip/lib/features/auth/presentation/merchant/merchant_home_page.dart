import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:hatlyai/features/auth/presentation/merchant/product_bloc/merchant_product_bloc.dart';
import 'package:hatlyai/features/auth/presentation/merchant/product_bloc/merchant_product_event.dart';
import 'package:hatlyai/features/auth/presentation/merchant/product_bloc/merchant_product_state.dart';

import 'merchant_orders_page.dart';

import 'add_product_page.dart';

class MerchantHomePage extends StatefulWidget {
  const MerchantHomePage({super.key});

  @override
  State<MerchantHomePage> createState() => _MerchantHomePageState();
}

class _MerchantHomePageState extends State<MerchantHomePage> {
  @override
  void initState() {
    super.initState();
    // 1. إطلاق حدث طلب جلب إحصائيات ومبيعات المتجر تلقائياً فور فتح الشاشة
    context.read<MerchantProductBloc>().add(GetMerchantStatsRequestedEvent());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF8F9FA),
      // 2. شريط الترويسة العلوي الأنيق لبوابة إدارة المتجر
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0.5,
        title: const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'لوحة تحكم التاجر 🏢',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: Colors.black87,
                fontFamily: 'Cairo',
              ),
            ),
            Text(
              'إدارة المنتجات والمبيعات الفورية',
              style: TextStyle(
                fontSize: 11,
                color: Colors.grey,
                fontFamily: 'Cairo',
              ),
            ),
          ],
        ),
        actions: [
          // زر الانتقال المباشر لشاشة استقبال وتتبع الطلبات الفورية الجديدة
          IconButton(
            icon: const Icon(
              Icons.shopping_cart_checkout_rounded,
              color: Colors.deepOrange,
              size: 26,
            ),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const MerchantOrdersPage(),
                ),
              );
            },
          ),

          IconButton(
            icon: const Icon(
              Icons.add_box_rounded,
              color: Colors.deepOrange,
              size: 28,
            ),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const AddProductPage()),
              );
            },
          ),
          const SizedBox(width: 8),
        ],
      ),
      // سيتم استدعاء الـ BlocBuilder وقائمة إدارة السلع الحية هنا في الجزء الثاني...
      body: SafeArea(
        child: BlocBuilder<MerchantProductBloc, MerchantProductState>(
          builder: (context, state) {
            // القيم الافتراضية الآمنة للإحصائيات في حالة التحميل أو البداية
            double totalSales = 0.0;
            int successfulOrders = 0;
            int activeProducts = 0;

            // 3. تحديث الأرقام ديناميكياً فور نجاح حالة جلب البيانات المالية الحية
            if (state is GetMerchantStatsSuccessState) {
              totalSales = state.stats.totalSales;
              successfulOrders = state.stats.successfulOrders;
              activeProducts = state.stats.activeProducts;
            }

            if (state is MerchantProductLoadingState) {
              return const Center(
                child: CircularProgressIndicator(color: Colors.deepOrange),
              );
            }

            return SingleChildScrollView(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  // لوحة الأداء المالي وإحصائيات المبيعات الحية التراكمية للمتجر
                  Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withValues(alpha: 0.02),
                          blurRadius: 10,
                          offset: const Offset(0, 4),
                        ),
                      ],
                      border: Border.all(
                        color: Colors.grey.withValues(alpha: 0.05),
                      ),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        _buildSummaryStat(
                          title: 'إجمالي المبيعات',
                          value: '${totalSales.toStringAsFixed(0)} ج.م',
                          icon: Icons.analytics_rounded,
                          color: Colors.blue,
                        ),
                        Container(
                          width: 1,
                          height: 40,
                          color: Colors.grey.withValues(alpha: 0.2),
                        ),
                        _buildSummaryStat(
                          title: 'الطلبات الناجحة',
                          value: '$successfulOrders طلب',
                          icon: Icons.check_circle_rounded,
                          color: Colors.green,
                        ),
                        Container(
                          width: 1,
                          height: 40,
                          color: Colors.grey.withValues(alpha: 0.2),
                        ),
                        _buildSummaryStat(
                          title: 'السلع النشطة',
                          value: '$activeProducts منتجات',
                          icon: Icons.inventory_2_rounded,
                          color: Colors.orange,
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 28),

                  // ترويسة إدارة المخزون مع زر التحديث اليدوي
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        'قائمة السلع والمنتجات المتاحة',
                        style: TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.bold,
                          color: Colors.black87,
                          fontFamily: 'Cairo',
                        ),
                      ),
                      TextButton.icon(
                        onPressed: () {
                          context.read<MerchantProductBloc>().add(
                            GetMerchantStatsRequestedEvent(),
                          );
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                              content: Text(
                                'جاري تحديث البيانات المالية ديناميكياً 🔄',
                              ),
                              duration: Duration(seconds: 1),
                            ),
                          );
                        },
                        icon: const Icon(
                          Icons.refresh_rounded,
                          size: 16,
                          color: Colors.deepOrange,
                        ),
                        label: const Text(
                          'تحديث',
                          style: TextStyle(
                            color: Colors.deepOrange,
                            fontSize: 13,
                            fontFamily: 'Cairo',
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),

                  // قائمة عرض وإدارة عناصر المخزون النشطة
                  ListView(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    children: [
                      _buildInventoryItem(
                        name: 'وجبة سوبر كومبو حار 🍔🔥',
                        category: 'مطاعم 🍔',
                        price: 135.0,
                        description:
                            'برجر دجاج مقرمش مع بطاطس ومشروب غازي كبير.',
                      ),
                      const SizedBox(height: 12),
                      _buildInventoryItem(
                        name: 'ساندوتش تشيز برجر دبل 🧀',
                        category: 'مطاعم 🍔',
                        price: 95.0,
                        description: 'قطعتين لحم مشوي مع جبنة شيدر صوص مميز.',
                      ),
                      const SizedBox(height: 12),
                      _buildInventoryItem(
                        name: 'علبة لبن طبيعي ١ لتر 🥛',
                        category: 'سوبرماركت 🛒',
                        price: 38.0,
                        description:
                            'حليب بقري طازج كامل الدسم معبأ بأعلى جودة.',
                      ),
                    ],
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }

  // ودجت فرعية لبناء عناصر الإحصائيات المالية بنقاء
  Widget _buildSummaryStat({
    required String title,
    required String value,
    required IconData icon,
    required Color color,
  }) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon, color: color, size: 22),
        const SizedBox(height: 6),
        Text(
          title,
          style: const TextStyle(
            fontSize: 11,
            color: Colors.grey,
            fontFamily: 'Cairo',
          ),
        ),
        const SizedBox(height: 2),
        Text(
          value,
          style: const TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.bold,
            color: Colors.black87,
            fontFamily: 'Cairo',
          ),
        ),
      ],
    );
  }

  // ودجت تصميم كروت المنتجات والمخزون بدون أي أخطاء
  Widget _buildInventoryItem({
    required String name,
    required String category,
    required double price,
    required String description,
  }) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: Colors.grey.withValues(alpha: 0.06),
          width: 1,
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 46,
            height: 46,
            decoration: BoxDecoration(
              color: Colors.deepOrange.withValues(alpha: 0.05),
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Icon(
              Icons.add_box_rounded,
              color: Colors.deepOrange,
              size: 24,
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child: Text(
                        name,
                        style: const TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                          color: Colors.black87,
                          fontFamily: 'Cairo',
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    Text(
                      '${price.toStringAsFixed(0)} ج.م',
                      style: const TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.bold,
                        color: Colors.green,
                        fontFamily: 'Cairo',
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 2),
                Text(
                  category,
                  style: const TextStyle(
                    fontSize: 11,
                    color: Colors.deepOrangeAccent,
                    fontFamily: 'Cairo',
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  description,
                  style: const TextStyle(
                    fontSize: 11,
                    color: Colors.grey,
                    fontFamily: 'Cairo',
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
