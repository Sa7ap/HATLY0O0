import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../auth/domain/usecases/get_driver_wallet_usecase.dart';
import '../../../../auth/domain/usecases/get_driver_shifts_usecase.dart';
import 'driver_wallet_event.dart';
import 'driver_wallet_state.dart';
import '../../../../auth/domain/entities/driver_shift_entity.dart';

class DriverWalletBloc extends Bloc<DriverWalletEvent, DriverWalletState> {
  final GetDriverWalletUseCase getDriverWalletUseCase;
  final GetDriverShiftsUseCase getDriverShiftsUseCase;

  DriverWalletBloc({
    required this.getDriverWalletUseCase,
    required this.getDriverShiftsUseCase,
  }) : super(DriverWalletInitialState()) {
    on<GetDriverWalletRequestedEvent>((event, emit) async {
      emit(DriverWalletLoadingState());
      await Future.delayed(const Duration(milliseconds: 500));
      emit(DriverWalletSuccessState());
    });

    // --- معالجة الحدث الجديد المضاف: تحديث الأرباح والورديات الحية للكابتن ---
    on<RefreshDriverWalletBalancesEvent>((event, emit) async {
      emit(DriverWalletLoadingState());

      // محاكاة الاتصال الآمن بالسيرفر وجلب المحفظة والوردية الجغرافية 30 كم
      await Future.delayed(const Duration(milliseconds: 600));

      // تصحيح: تمرير المعاملات الصارمة والمطابقة تماماً لتوقيع الكيان بمشروعك
      final mockShifts = [
        const DriverShiftEntity(
          id: 'shift_2026',
          orderSummary: 'طلب توصيل حُر',
          deliveryEarnings: 450.0,
          distance: '30 كم',
          date: '2026-10-11',
        ),
      ];

      emit(
        DriverWalletBalancesLoadedState(
          totalEarnings: 450.0, // تثبيت أرباح التوصيل التراكمية للكابتن حياً
          activeShifts: mockShifts,
        ),
      );
    });
  }
}
