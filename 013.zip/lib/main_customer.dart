import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import 'core/utils/service_locator.dart';
import 'core/welcome_page.dart';
import 'features/auth/presentation/customer/bloc/auth_bloc.dart';

void main() async {
  // 1. التأكد من تهيئة روابط إطار عمل فلاتر قبل أي عملية برمجية
  WidgetsFlutterBinding.ensureInitialized();

  // 2. تشغيل حاوية حقن التبعيات وتجهيز الكلاسات في الذاكرة
  await initServiceLocator();

  runApp(const MyCustomerApp());
}

class MyCustomerApp extends StatelessWidget {
  const MyCustomerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider<AuthBloc>(
      // جلب نسخة الـ AuthBloc المحقونة تلقائياً من الـ Service Locator
      create: (context) => sl<AuthBloc>(),
      child: MaterialApp(
        title: 'هاتلي - تطبيق العميل',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          primarySwatch: Colors.deepOrange,
          primaryColor: Colors.deepOrange,
          scaffoldBackgroundColor: Colors.white,
          fontFamily: 'Cairo', // تنسيق الخط العربي الافتراضي
          appBarTheme: const AppBarTheme(
            backgroundColor: Colors.transparent,
            elevation: 0,
            iconTheme: IconThemeData(color: Colors.black87),
          ),
        ),
        // نقطة البداية هي صفحة الترحيب المحسنة
        home: const WelcomePage(),
      ),
    );
  }
}
