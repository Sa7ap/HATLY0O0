import 'package:flutter/material.dart';

import '../../../../core/shared_widgets/star_rating_bar.dart'; // استدعاء شريط النجوم التفاعلي

class CustomerEvaluationPage extends StatefulWidget {
  final String orderId;
  const CustomerEvaluationPage({super.key, required this.orderId});

  @override
  State<CustomerEvaluationPage> createState() => _CustomerEvaluationPageState();
}

class _CustomerEvaluationPageState extends State<CustomerEvaluationPage> {
  int _selectedStars = 5; // تقييم افتراضي كامل
  final TextEditingController _commentController = TextEditingController();

  @override
  void dispose() {
    _commentController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: const Text(
          'تقييم الخدمة والمندوب ⭐️',
          style: TextStyle(
            fontFamily: 'Cairo',
            fontSize: 14,
            fontWeight: FontWeight.bold,
            color: Colors.black87,
          ),
        ),
        centerTitle: true,
        backgroundColor: Colors.white,
        elevation: 0.5,
      ),
      body: ListView(
        padding: const EdgeInsets.all(24.0),
        children: [
          const Text(
            'كيف كانت تجربة التوصيل الحر للطلب؟',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontFamily: 'Cairo',
              fontSize: 14,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 24),

          // دمج شريط النجوم التفاعلي الجديد حركياً لعام 2026
          StarRatingBar(
            rating: _selectedStars,
            onRatingChanged: (stars) => setState(() => _selectedStars = stars),
          ),

          const SizedBox(height: 32),
          TextFormField(
            controller: _commentController,
            maxLines: 3,
            decoration: const InputDecoration(
              hintText: 'اكتب تعليقك أو ملاحظاتك هنا للكابتن ومتجر سمنود...',
              hintStyle: TextStyle(fontSize: 12, fontFamily: 'Cairo'),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.all(Radius.circular(12)),
              ),
            ),
          ),
          const SizedBox(height: 40),
          ElevatedButton(
            onPressed: () => Navigator.pop(context),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.deepOrange,
              padding: const EdgeInsets.symmetric(vertical: 14),
            ),
            child: const Text(
              'إرسال التقييم النهائي',
              style: TextStyle(
                fontFamily: 'Cairo',
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
