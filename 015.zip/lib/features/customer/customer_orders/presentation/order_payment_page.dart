import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import 'bloc/customer_order_bloc.dart';
import 'bloc/customer_order_event.dart';
import 'bloc/customer_order_state.dart';
import '../domain/entities/payment_entity.dart';
import 'order_tracker_view.dart';

class OrderPaymentPage extends StatefulWidget {
  final String orderId;
  final double totalAmount;

  const OrderPaymentPage({
    super.key,
    required this.orderId,
    required this.totalAmount,
  });

  @override
  State<OrderPaymentPage> createState() => _OrderPaymentPageState();
}

class _OrderPaymentPageState extends State<OrderPaymentPage> {
  String _selectedMethod = 'CASH'; // طريقة الدفع الافتراضية المحددة

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF8F9FA),
      appBar: AppBar(
        title: const Text(
          'تأكيد وسداد الفاتورة 💳',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            color: Colors.black87,
            fontFamily: 'Cairo',
            fontSize: 15,
          ),
        ),
        centerTitle: true,
        backgroundColor: Colors.white,
        elevation: 0.5,
        leading: IconButton(
          icon: const Icon(
            Icons.arrow_back_ios_new_rounded,
            color: Colors.black87,
            size: 20,
          ),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      // يتبع مباشرة وتلقائياً الجزء 2 من 2 لبناء واجهة الراديو وزر التأكيد الحركي...
      body: SafeArea(
        child: BlocConsumer<CustomerOrderBloc, CustomerOrderState>(
          listener: (context, state) {
            // الاستماع لحالة نجاح اقتطاع الفاتورة وسداد الطلب بنجاح للتوجه لتتبع الكابتن
            if (state is ProcessOrderPaymentSuccessState) {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text(
                    'تم تأكيد عملية السداد وحفظ الفاتورة بنجاح! 💳✅',
                  ),
                  backgroundColor: Colors.green,
                ),
              );
              // التوجيه الحركي المباشر لشاشة التتبع الجغرافي الحي للطلب لعام 2026
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                  builder: (context) =>
                      OrderTrackerView(orderId: widget.orderId),
                ),
              );
            } else if (state is CustomerOrderFailureState) {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text(state.errorMessage),
                  backgroundColor: Colors.red,
                ),
              );
            }
          },
          builder: (context, state) {
            return ListView(
              padding: const EdgeInsets.all(20),
              children: [
                // بطاقة ملخص مالي للفاتورة الصافية للسلة
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: Colors.grey.withOpacity(0.06)),
                  ),
                  child: Column(
                    children: [
                      const Icon(
                        Icons.account_balance_wallet_rounded,
                        color: Colors.deepOrange,
                        size: 40,
                      ),
                      const SizedBox(height: 12),
                      const Text(
                        'إجمالي المبلغ المستحق سداده:',
                        style: TextStyle(
                          fontFamily: 'Cairo',
                          fontSize: 13,
                          color: Colors.grey,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        '${widget.totalAmount.toStringAsFixed(0)} ج.م',
                        style: const TextStyle(
                          fontFamily: 'Cairo',
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                          color: Colors.black87,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 28),

                const Text(
                  'اختر طريقة السداد المناسبة للتوصيل:',
                  style: TextStyle(
                    fontFamily: 'Cairo',
                    fontSize: 13,
                    fontWeight: FontWeight.bold,
                    color: Colors.black87,
                  ),
                ),
                const SizedBox(height: 12),

                // الخيار الأول: الدفع النقدي عند الاستلام (COD)
                _buildPaymentMethodOption(
                  title: 'الدفع نقداً عند الاستلام (كاش) 💵',
                  value: 'CASH',
                  subtitle:
                      'سداد قيمة الفاتورة يدوياً للكابتن فور تسليم الوجبات',
                ),
                const SizedBox(height: 12),

                // الخيار الثاني: الدفع الحركي التفاعلي خصماً من رصيد المحفظة الإلكترونية
                _buildPaymentMethodOption(
                  title: 'رصيد المحفظة الإلكترونية لـ هاتلي 📱',
                  value: 'WALLET',
                  subtitle:
                      'الخصم الفوري والآمن للفاتورة من رصيدك المتاح حالياً',
                ),
                const SizedBox(height: 40),

                // زر التثبيت والسداد النهائي المحمي بالكامل
                ElevatedButton(
                  onPressed: state is CustomerOrderLoadingState
                      ? null
                      : () {
                          // تصحيح معماري: تمرير قيم فرز مستحقات الأطراف الثلاثة لحسم خطأ السداد
                          final payment = PaymentEntity(
                            transactionId: DateTime.now().millisecondsSinceEpoch
                                .toString(),
                            orderId: widget.orderId,
                            paymentMethod: _selectedMethod,
                            amountPaid: widget.totalAmount,
                            paymentStatus: 'SUCCESS',
                            merchantShare:
                                widget.totalAmount -
                                40.0, // فرضية صافي مستحقات التاجر عن السلع
                            deliveryFee: 30.0, // صافي حق كابتن التوصيل جغرافياً
                            platformFee: 10.0, // رسوم تشغيل منصة هاتلي الذكية
                          );

                          // إطلاق حدث معالجة الدفع الرقمي حركياً بالـ Bloc المعتمد بمشروعك
                          context.read<CustomerOrderBloc>().add(
                            ProcessOrderPaymentEvent(payment: payment),
                          );
                        },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.green,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    elevation: 0,
                  ),
                  child: state is CustomerOrderLoadingState
                      ? const SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(
                            color: Colors.white,
                            strokeWidth: 2,
                          ),
                        )
                      : const Text(
                          'تأكيد وسداد الفاتورة الحالية',
                          style: TextStyle(
                            fontFamily: 'Cairo',
                            fontWeight: FontWeight.bold,
                            fontSize: 14,
                          ),
                        ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }

  // ودجت مخصصة لبناء وهندسة كروت الراديو لطرق الدفع بنقاء هندسي كامل
  Widget _buildPaymentMethodOption({
    required String title,
    required String value,
    required String subtitle,
  }) {
    final isSelected = _selectedMethod == value;
    return InkWell(
      onTap: () {
        setState(() {
          _selectedMethod = value;
        });
      },
      borderRadius: BorderRadius.circular(14),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: isSelected ? Colors.green : Colors.grey.withOpacity(0.06),
            width: isSelected ? 1.5 : 1.0,
          ),
        ),
        child: Row(
          children: [
            Radio<String>(
              value: value,
              groupValue: _selectedMethod,
              activeColor: Colors.green,
              onChanged: (val) {
                setState(() {
                  _selectedMethod = val!;
                });
              },
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      fontFamily: 'Cairo',
                      fontSize: 13,
                      fontWeight: FontWeight.bold,
                      color: Colors.black87,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    subtitle,
                    style: const TextStyle(
                      fontFamily: 'Cairo',
                      fontSize: 10,
                      color: Colors.grey,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
