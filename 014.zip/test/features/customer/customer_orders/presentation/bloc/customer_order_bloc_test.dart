import 'package:flutter_test/flutter_test.dart';
import 'package:bloc_test/bloc_test.dart';
import 'package:mockito/mockito.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:hatlyai/features/customer/customer_orders/presentation/bloc/customer_order_bloc.dart';
import 'package:hatlyai/features/customer/customer_orders/presentation/bloc/customer_order_event.dart';
import 'package:hatlyai/features/customer/customer_orders/presentation/bloc/customer_order_state.dart';
import 'package:hatlyai/features/customer/customer_orders/domain/usecases/create_order_usecase.dart';
import 'package:hatlyai/features/customer/customer_orders/domain/usecases/update_order_status_usecase.dart';
import 'package:hatlyai/features/customer/customer_orders/domain/usecases/get_notifications_usecase.dart';
import 'package:hatlyai/features/customer/customer_orders/domain/usecases/submit_order_evaluation_usecase.dart';
import 'package:hatlyai/features/customer/customer_orders/domain/usecases/get_order_history_usecase.dart';
import 'package:hatlyai/features/customer/customer_orders/domain/usecases/get_chat_messages_usecase.dart';
import 'package:hatlyai/features/customer/customer_orders/domain/usecases/send_chat_message_usecase.dart';
import 'package:hatlyai/features/customer/customer_orders/domain/usecases/get_saved_addresses_usecase.dart';
import 'package:hatlyai/features/customer/customer_orders/domain/usecases/save_new_address_usecase.dart';
import 'package:hatlyai/features/customer/customer_orders/domain/usecases/update_customer_profile_usecase.dart';
import 'package:hatlyai/features/customer/customer_orders/domain/usecases/process_order_payment_usecase.dart';
import 'package:hatlyai/features/customer/customer_orders/domain/usecases/get_payment_receipt_usecase.dart';
// تصحيح: استدعاء كيانات الـ Domain المعتمدة بمشروعك الحقيقي لإنهاء الأخطاء
import 'package:hatlyai/features/customer/customer_orders/domain/entities/cart_item_entity.dart';
import 'package:hatlyai/features/customer/customer_orders/domain/entities/settings_entity.dart';

class MockCreateOrderUseCase extends Mock implements CreateOrderUseCase {}

class MockUpdateOrderStatusUseCase extends Mock
    implements UpdateOrderStatusUseCase {}

class MockGetNotificationsUseCase extends Mock
    implements GetNotificationsUseCase {}

class MockSubmitOrderEvaluationUseCase extends Mock
    implements SubmitOrderEvaluationUseCase {}

class MockGetOrderHistoryUseCase extends Mock
    implements GetOrderHistoryUseCase {}

class MockGetChatMessagesUseCase extends Mock
    implements GetChatMessagesUseCase {}

class MockSendChatMessageUseCase extends Mock
    implements SendChatMessageUseCase {}

class MockGetSavedAddressesUseCase extends Mock
    implements GetSavedAddressesUseCase {}

class MockSaveNewAddressUseCase extends Mock implements SaveNewAddressUseCase {}

class MockUpdateCustomerProfileUseCase extends Mock
    implements UpdateCustomerProfileUseCase {}

class MockProcessOrderPaymentUseCase extends Mock
    implements ProcessOrderPaymentUseCase {}

class MockGetPaymentReceiptUseCase extends Mock
    implements GetPaymentReceiptUseCase {}

class MockSharedPreferences extends Mock implements SharedPreferences {}

void main() {
  late CustomerOrderBloc bloc;
  late MockProcessOrderPaymentUseCase mockProcessOrderPaymentUseCase;
  late MockGetPaymentReceiptUseCase mockGetPaymentReceiptUseCase;
  late MockSharedPreferences mockSharedPreferences;

  setUp(() {
    mockProcessOrderPaymentUseCase = MockProcessOrderPaymentUseCase();
    mockGetPaymentReceiptUseCase = MockGetPaymentReceiptUseCase();
    mockSharedPreferences = MockSharedPreferences();

    bloc = CustomerOrderBloc(
      createOrderUseCase: MockCreateOrderUseCase(),
      updateOrderStatusUseCase: MockUpdateOrderStatusUseCase(),
      getNotificationsUseCase: MockGetNotificationsUseCase(),
      submitOrderEvaluationUseCase: MockSubmitOrderEvaluationUseCase(),
      getOrderHistoryUseCase: MockGetOrderHistoryUseCase(),
      getChatMessagesUseCase: MockGetChatMessagesUseCase(),
      sendChatMessageUseCase: MockSendChatMessageUseCase(),
      getSavedAddressesUseCase: MockGetSavedAddressesUseCase(),
      saveNewAddressUseCase: MockSaveNewAddressUseCase(),
      updateCustomerProfileUseCase: MockUpdateCustomerProfileUseCase(),
      processOrderPaymentUseCase: mockProcessOrderPaymentUseCase,
      getPaymentReceiptUseCase: mockGetPaymentReceiptUseCase,
      sharedPreferences: mockSharedPreferences,
    );
  });

  tearDown(() {
    bloc.close();
  });

  test(
    'الحالة الابتدائية للـ Bloc يجب أن تكون من نوع CustomerOrderInitialState',
    () {
      expect(bloc.state, isA<CustomerOrderInitialState>());
    },
  );
  // يتبع مباشرة وتلقائياً الجزء 2 من 2 بالرد القادم دون أي توقف...
  blocTest<CustomerOrderBloc, CustomerOrderState>(
    'يجب أن يطلق [CustomerOrderLoadingState] ثم [CartItemQuantityUpdatedState] عند نجاح تحديث كمية المنتج بالسلة',
    build: () => bloc,
    act: (bloc) => bloc.add(
      UpdateCartItemQuantityEvent(
        cartItem: const CartItemEntity(
          id: 'item_1',
          name: 'وجبة سوبر كومبو',
          price: 135.0,
          quantity: 1,
        ),
        newQuantity: 3,
      ),
    ),
    expect: () => [
      isA<CartItemQuantityUpdatedState>().having(
        (state) => state.updatedQuantity,
        'الكمية المحدثة',
        3,
      ),
    ],
  );

  blocTest<CustomerOrderBloc, CustomerOrderState>(
    'يجب أن يطلق [CustomerOrderLoadingState] ثم [AppSettingsUpdatedState] عند تعديل خيارات الثيم المظلم واللغة بنجاح',
    build: () {
      when(
        mockSharedPreferences.setBool(
          anyNamed('key') ?? '',
          anyNamed('value') ?? true,
        ),
      ).thenAnswer((_) => Future.value(true));
      when(
        mockSharedPreferences.setString(
          anyNamed('key') ?? '',
          anyNamed('value') ?? '',
        ),
      ).thenAnswer((_) => Future.value(true));
      return bloc;
    },
    act: (bloc) => bloc.add(
      const UpdateAppSettingsEvent(
        settings: SettingsEntity(
          isDarkMode: true,
          selectedLanguage: 'ar',
          isNotificationsOn: true,
        ),
      ),
    ),
    expect: () => [
      CustomerOrderLoadingState(),
      isA<AppSettingsUpdatedState>().having(
        (state) => state.settings.isDarkMode,
        'الوضع المظلم',
        true,
      ),
    ],
  );
}
