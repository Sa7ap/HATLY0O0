abstract class Failure {
  final String message;
  const Failure(this.message);
}

// خطأ قادم من السيرفر أو قاعدة البيانات
class ServerFailure extends Failure {
  const ServerFailure(super.message);
}

// خطأ في الاتصال بالإنترنت
class NetworkFailure extends Failure {
  // الحل: نمرر القيمة الافتراضية إلى كونتراكتور الأب عبر : super()
  const NetworkFailure([
    super.message = "لا يوجد اتصال بالإنترنت، يرجى التحقق من الشبكة",
  ]);
}

// خطأ في إدخال البيانات أو التحقق من الحقول
class ValidationFailure extends Failure {
  const ValidationFailure(super.message);
}
