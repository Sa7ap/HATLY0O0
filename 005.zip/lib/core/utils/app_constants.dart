class AppConstants {
  static const String appName = "تطبيق توصيل الطلبات";

  // إعدادات رسوم التوصيل الافتراضية
  static const double initialDeliveryFee = 0.0;

  // نوع المصادقة الأساسي المعتمد في المشروع
  static const String authMethod = "PHONE_NUMBER";
}
