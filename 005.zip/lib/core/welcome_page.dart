import 'package:flutter/material.dart';

// استيراد شاشات الدخول الثلاث التي قمنا ببنائها وتفعيلها
import '../features/auth/presentation/customer/login_phone_page.dart';
import '../features/auth/presentation/driver/driver_login_page.dart';
import '../features/auth/presentation/merchant/merchant_login_page.dart';

class WelcomePage extends StatelessWidget {
  const WelcomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 30.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // أيقونة التطبيق الكبيرة والجميلة
              const Icon(
                Icons.delivery_dining_rounded,
                size: 96,
                color: Colors.deepOrange,
              ),
              const SizedBox(height: 16),
              const Text(
                'مرحباً بك في هاتلي',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                  color: Colors.deepOrange,
                ),
              ),
              const SizedBox(height: 8),
              const Text(
                'اختر نوع حسابك لبدء استخدام المنصة والولوج لبوابتك المخصصة',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 14, color: Colors.grey, height: 1.4),
              ),
              const SizedBox(height: 48),

              // 1. زر الدخول كـ عميل
              _buildRoleButton(
                context,
                title: 'أنا عميل (أريد الطلب)',
                icon: Icons.person_rounded,
                color: Colors.deepOrange,
                // الاسم المصحح والمطابق لملفاتك الحقيقية تماماً
                targetPage: const LoginPhonePage(),
              ),
              const SizedBox(height: 16),

              // 2. زر الدخول كـ مندوب / كابتن
              _buildRoleButton(
                context,
                title: 'أنا مندوب توصيل (كابتن)',
                icon: Icons.local_shipping_rounded,
                color: Colors.green,
                targetPage: const DriverLoginPage(),
              ),
              const SizedBox(height: 16),

              // 3. زر الدخول كـ تاجر / شريك لشاشتك الجديدة
              _buildRoleButton(
                context,
                title: 'أنا تاجر (صاحب محل أو مطعم)',
                icon: Icons.storefront_rounded,
                color: Colors.blueAccent,
                targetPage: const MerchantLoginPage(),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // دالة مساعدة لبناء أزرار الأطراف بشكل متناسق وموحد
  Widget _buildRoleButton(
    BuildContext context, {
    required String title,
    required IconData icon,
    required Color color,
    required Widget targetPage,
  }) {
    return SizedBox(
      height: 56,
      child: ElevatedButton.icon(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => targetPage),
          );
        },
        icon: Icon(icon, size: 22),
        label: Text(
          title,
          style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
        ),
        style: ElevatedButton.styleFrom(
          backgroundColor: color,
          foregroundColor: Colors.white,
          elevation: 0,
          alignment:
              Alignment.centerRight, // محاذاة النص والأيقونة لليمين العربي
          padding: const EdgeInsets.symmetric(horizontal: 20),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16.0),
          ),
        ),
      ),
    );
  }
}
