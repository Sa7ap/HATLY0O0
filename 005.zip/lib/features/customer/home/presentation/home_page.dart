import 'package:flutter/material.dart';

import 'home_content.dart'; // استدعاء المحتوى الذكي المحسن
import 'notification_center_page.dart'; // استدعاء صفحة الإشعارات المتواجدة بمشروعك

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF8F9FA),
      // 1. شريط الترويسة العلوي المطور للعميل
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0.5,
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'التوصيل إلى',
              style: TextStyle(
                fontSize: 12,
                color: Colors.grey,
                fontFamily: 'Cairo',
              ),
            ),
            Row(
              children: [
                const Icon(
                  Icons.location_on,
                  size: 16,
                  color: Colors.deepOrange,
                ),
                const SizedBox(width: 4),
                Expanded(
                  child: Text(
                    'تحديد الموقع الحالي عبر الـ GPS...',
                    style: const TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                      color: Colors.black87,
                      fontFamily: 'Cairo',
                    ),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ],
            ),
          ],
        ),
        actions: [
          // زر الانتقال لمركز الإشعارات المكتوب في مشروعك مسبقاً
          IconButton(
            icon: const Icon(
              Icons.notifications_none_rounded,
              color: Colors.black87,
            ),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const NotificationCenterPage(),
                ),
              );
            },
          ),
        ],
      ),
      // يتبع في الجزء الثاني محتوى الـ body وقفل الكلاس...
      // 2. ربط محتوى الصفحة بالـ HomeContent الذكي الذي قمنا بإصلاحه وتجهيزه
      body: const SafeArea(child: HomeContent()),
    ); // قفل الـ Scaffold
  }
}
