import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'bloc/customer_order_bloc.dart';
import 'bloc/customer_order_event.dart';
import 'bloc/customer_order_state.dart';
import '../domain/entities/past_order_entity.dart';

class OrderHistoryPage extends StatefulWidget {
  const OrderHistoryPage({super.key});

  @override
  State<OrderHistoryPage> createState() => _OrderHistoryPageState();
}

class _OrderHistoryPageState extends State<OrderHistoryPage> {
  @override
  void initState() {
    super.initState();
    // 1. إطلاق حدث طلب جلب سجل الفواتير والأرشيف تلقائياً فور فتح الشاشة لعام 2026
    context.read<CustomerOrderBloc>().add(GetOrderHistoryEvent());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF8F9FA),
      // 2. شريط الترويسة العلوي الأنيق لأرشيف فواتير العميل
      appBar: AppBar(
        title: const Text(
          'سجل الطلبات والفواتير 📄',
          style: TextStyle(fontWeight: FontWeight.bold, color: Colors.black87, fontFamily: 'Cairo', fontSize: 15),
        ),
        centerTitle: true,
        backgroundColor: Colors.white,
        elevation: 0.5,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, color: Colors.black87, size: 20),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      // سيتم ربط الـ BlocBuilder وتفاصيل الكروت الرأسية بالأسفل في الجزء الثاني...
      body: SafeArea(
        child: BlocBuilder<CustomerOrderBloc, CustomerOrderState>(
          builder: (context, state) {
            List<PastOrderEntity> historyList = [];

            // 3. استخراج مصفوفة الأرشيف الحية فور تحميلها بنجاح من الـ Bloc
            if (state is GetOrderHistorySuccessState) {
              historyList = state.orders;
            }

            if (state is CustomerOrderLoadingState && historyList.isEmpty) {
              return const Center(child: CircularProgressIndicator(color: Colors.deepOrange));
            }

            return RefreshIndicator(
              onRefresh: () async {
                context.read<CustomerOrderBloc>().add(GetOrderHistoryEvent());
              },
              color: Colors.deepOrange,
              child: ListView(
                padding: const EdgeInsets.all(16.0),
                children: [
                  historyList.isEmpty
                      ? Container(
                          padding: const EdgeInsets.all(24),
                          height: MediaQuery.of(context).size.height * 0.6,
                          child: const Center(
                            child: Text(
                              'لا توجد طلبات سابقة في أرشيفك حالياً.',
                              style: TextStyle(fontFamily: 'Cairo', fontSize: 13, color: Colors.grey),
                            ),
                          ),
                        )
                      : ListView.builder(
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          itemCount: historyList.length,
                          itemBuilder: (context, index) {
                            final pastOrder = historyList[index];
                            return _buildPastOrderCardItem(pastOrder);
                          },
                        ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }

  // 4. ودجت بناء وتنسيق كروت الفواتير التاريخية المكتملة رأسيّاً بنقاء
  Widget _buildPastOrderCardItem(PastOrderEntity order) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.grey.withOpacity(0.06)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.01),
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // رأس الكارت: كود الفاتورة الفريد وتاريخ المعاملة الماليّة
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'طلب رقم: #${order.orderCode}',
                style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold, fontFamily: 'Cairo', color: Colors.black87),
              ),
              Text(
                order.dateTime,
                style: const TextStyle(fontSize: 11, color: Colors.grey, fontFamily: 'Cairo'),
              ),
            ],
          ),
          const Divider(height: 20, thickness: 0.8),

          // سلع المشتريات الموصلة
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Icon(Icons.shopping_bag_outlined, color: Colors.deepOrange, size: 18),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  order.orderDetails,
                  style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: Colors.black87, fontFamily: 'Cairo', height: 1.4),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),

          // موقع الاستلام الجغرافي (التاجر)
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Icon(Icons.storefront_rounded, color: Colors.blue, size: 16),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  'من: ${order.pickupLocation}',
                  style: const TextStyle(fontSize: 11, color: Colors.grey, fontFamily: 'Cairo'),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
          const SizedBox(height: 4),

          // موقع التسليم الجغرافي (العميل)
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Icon(Icons.location_on_outlined, color: Colors.green, size: 16),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  'إلى: ${order.deliveryLocation}',
                  style: const TextStyle(fontSize: 11, color: Colors.grey, fontFamily: 'Cairo'),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
          const Divider(height: 24, thickness: 0.8),

          // الفواتير الماليّة والتقييمات المحفوظة
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('رسوم التوصيل الصافية:', style: TextStyle(fontSize: 10, color: Colors.grey, fontFamily: 'Cairo')),
                  const SizedBox(height: 2),
                  Text(
                    '${order.deliveryFee.toStringAsFixed(0)} ج.م',
                    style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: Colors.green, fontFamily: 'Cairo'),
                  ),
                ],
              ),
              
              // عرض التقييمات المحفوظة للكابتن والمتجر بنقاء بصرى
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Row(
                    children: [
                      const Text('تقييم الكابتن: ', style: TextStyle(fontSize: 9, color: Colors.grey, fontFamily: 'Cairo')),
                      const Icon(Icons.star_rounded, color: Colors.amber, size: 12),
                      Text(' ${order.driverRating}', style: const TextStyle(fontSize: 10, fontWeight: FontWeight.bold, fontFamily: 'Cairo')),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      const Text('تقييم المتجر: ', style: TextStyle(fontSize: 9, color: Colors.grey, fontFamily: 'Cairo')),
                      const Icon(Icons.store_mall_directory_rounded, color: Colors.orange, size: 12),
                      Text(' ${order.storeRating}', style: const TextStyle(fontSize: 10, fontWeight: FontWeight.bold, fontFamily: 'Cairo')),
                    ],
                  ),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }
}
