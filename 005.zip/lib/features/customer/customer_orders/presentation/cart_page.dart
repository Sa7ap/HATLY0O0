import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import 'bloc/customer_order_bloc.dart';
import 'bloc/customer_order_event.dart';
import 'bloc/customer_order_state.dart';

// تعريف محلي آمن لكائن عناصر السلة لمنع أي تعارض في المسارات
class LocalCartItem {
  final String id;
  final String name;
  final double price;
  int quantity;

  LocalCartItem({
    required this.id,
    required this.name,
    required this.price,
    required this.quantity,
  });
}

class CartPage extends StatefulWidget {
  const CartPage({super.key});

  @override
  State<CartPage> createState() => _CartPageState();
}

class _CartPageState extends State<CartPage> {
  // قائمة افتراضية تفاعلية لعناصر السلة (وجبة برجر وعلبة لبن طبيعي)
  final List<LocalCartItem> _cartItems = [
    LocalCartItem(
      id: 'prod_01',
      name: 'وجبة سوبر كومبو حار 🍔🔥',
      price: 135.0,
      quantity: 2,
    ),
    LocalCartItem(
      id: 'prod_03',
      name: 'علبة لبن طبيعي ١ لتر 🥛',
      price: 38.0,
      quantity: 1,
    ),
  ];

  // دالة حساب السعر الإجمالي لكافة السلع داخل السلة ديناميكياً
  double get _totalPrice {
    return _cartItems.fold(
      0.0,
      (sum, item) => sum + (item.price * item.quantity),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF8F9FA),
      appBar: AppBar(
        title: const Text(
          'سلة المشتريات 🛒',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            color: Colors.black87,
            fontFamily: 'Cairo',
            fontSize: 16,
          ),
        ),
        centerTitle: true,
        backgroundColor: Colors.white,
        elevation: 0.5,
        leading: IconButton(
          icon: const Icon(
            Icons.arrow_back_ios_new_rounded,
            color: Colors.black87,
          ),
          onPressed: () => Navigator.pop(context),
        ),
        actions: [
          if (_cartItems.isNotEmpty)
            IconButton(
              icon: const Icon(
                Icons.delete_sweep_rounded,
                color: Colors.redAccent,
                size: 26,
              ),
              onPressed: () {
                setState(() {
                  _cartItems.clear();
                });
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('تم تفريغ السلة بالكامل! 🛒🧹'),
                    backgroundColor: Colors.black87,
                  ),
                );
              },
            ),
        ],
      ),
      body: SafeArea(
        child: BlocBuilder<CustomerOrderBloc, CustomerOrderState>(
          builder: (context, state) {
            if (_cartItems.isEmpty) {
              return Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      Icons.shopping_basket_outlined,
                      size: 64,
                      color: Colors.grey.withOpacity(0.4),
                    ),
                    const SizedBox(height: 16),
                    const Text(
                      'سلتك فارغة حالياً.\nقم بإضافة بعض المنتجات من المتاجر لقائمة التسوق.',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontFamily: 'Cairo',
                        fontSize: 13,
                        color: Colors.grey,
                        height: 1.5,
                      ),
                    ),
                  ],
                ),
              );
            }

            return Column(
              children: [
                Expanded(
                  child: ListView.builder(
                    padding: const EdgeInsets.all(16),
                    itemCount: _cartItems.length,
                    itemBuilder: (context, index) {
                      final item = _cartItems[index];
                      return _buildCartCard(item);
                    },
                  ),
                ),

                // لوحة حساب الفاتورة وزر إرسال الطلب الحر
                Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.04),
                        blurRadius: 10,
                        offset: const Offset(0, -4),
                      ),
                    ],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text(
                            'إجمالي الحساب الصافي:',
                            style: TextStyle(
                              fontFamily: 'Cairo',
                              fontSize: 14,
                              color: Colors.black54,
                            ),
                          ),
                          Text(
                            '${_totalPrice.toStringAsFixed(0)} ج.م',
                            style: const TextStyle(
                              fontFamily: 'Cairo',
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              color: Colors.green,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),
                      ElevatedButton(
                        onPressed: state is CustomerOrderLoadingState
                            ? null
                            : () {
                                // تجهيز بيانات السلة وإرسالها للـ Bloc المعتمد بنجاح
                                final orderData = {
                                  'items': _cartItems
                                      .map(
                                        (e) => {
                                          'id': e.id,
                                          'quantity': e.quantity,
                                        },
                                      )
                                      .toList(),
                                  'total_price': _totalPrice,
                                };
                                context.read<CustomerOrderBloc>().add(
                                  CreateOrderRequestedEvent(orderData),
                                );
                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(
                                    content: Text(
                                      'جاري إرسال وتأكيد طلبك الحر... ⏳',
                                    ),
                                    backgroundColor: Colors.deepOrange,
                                  ),
                                );
                              },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.deepOrange,
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                        child: state is CustomerOrderLoadingState
                            ? const SizedBox(
                                width: 20,
                                height: 20,
                                child: CircularProgressIndicator(
                                  color: Colors.white,
                                  strokeWidth: 2,
                                ),
                              )
                            : const Text(
                                'تأكيد وإرسال الطلب الحر',
                                style: TextStyle(
                                  fontFamily: 'Cairo',
                                  fontSize: 14,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                      ),
                    ],
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }

  Widget _buildCartCard(LocalCartItem item) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.grey.withOpacity(0.06)),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: Colors.deepOrange.withOpacity(0.05),
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Icon(
              Icons.fastfood_rounded,
              color: Colors.deepOrange,
              size: 22,
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  item.name,
                  style: const TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.bold,
                    color: Colors.black87,
                    fontFamily: 'Cairo',
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  '${item.price.toStringAsFixed(0)} ج.م',
                  style: const TextStyle(
                    fontSize: 12,
                    color: Colors.green,
                    fontWeight: FontWeight.w600,
                    fontFamily: 'Cairo',
                  ),
                ),
              ],
            ),
          ),

          // متحكمات زيادة ونقصان الأعداد التفاعلية المحلية لمنع الخطوط الحمراء
          Row(
            children: [
              IconButton(
                onPressed: () {
                  setState(() {
                    if (item.quantity > 1) {
                      item.quantity--;
                    } else {
                      _cartItems.remove(item);
                    }
                  });
                },
                icon: const Icon(
                  Icons.remove_circle_outline_rounded,
                  color: Colors.grey,
                  size: 22,
                ),
              ),
              Text(
                '${item.quantity}',
                style: const TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  color: Colors.black87,
                  fontFamily: 'Cairo',
                ),
              ),
              IconButton(
                onPressed: () {
                  setState(() {
                    item.quantity++;
                  });
                },
                icon: const Icon(
                  Icons.add_circle_rounded,
                  color: Colors.deepOrange,
                  size: 22,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
