import 'package:equatable/equatable.dart';

class MessageEntity extends Equatable {
  final String messageId; // المعرف الفريد للرسالة
  final String senderId; // معرف المرسل (العميل أو الكابتن)
  final String text; // نص الرسالة المكتوبة
  final String timestamp; // وقت إرسال الرسالة الفوري

  const MessageEntity({
    required this.messageId,
    required this.senderId,
    required this.text,
    required this.timestamp,
  });

  @override
  List<Object?> get props => [messageId, senderId, text, timestamp];
}
