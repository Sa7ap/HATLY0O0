import 'package:dartz/dartz.dart';
import 'package:flutter/material.dart';
import 'package:hatlyai/core/errors/failures.dart';

import '../../data/datasources/order_remote_data_source.dart';
import '../../data/models/notification_model.dart';
import '../../data/models/past_order_model.dart';
import '../../data/models/message_model.dart';
import '../../data/models/address_model.dart';
import '../../domain/entities/order_entity.dart';
import '../../domain/entities/notification_entity.dart';
import '../../domain/entities/evaluation_entity.dart';
import '../../domain/entities/past_order_entity.dart';
import '../../domain/entities/message_entity.dart';
import '../../domain/entities/address_entity.dart';
import '../../domain/repositories/order_repository.dart';

class OrderRepositoryImpl implements OrderRepository {
  final OrderRemoteDataSource remoteDataSource;

  OrderRepositoryImpl({required this.remoteDataSource});

  @override
  Future<Either<Failure, void>> createOrder(OrderEntity order) async {
    try {
      await Future.delayed(const Duration(seconds: 1));
      return const Right(null);
    } catch (e) {
      return Left(ServerFailure(e.toString()));
    }
  }

  @override
  Future<Either<Failure, void>> updateOrderStatus(
    String orderId,
    String status,
  ) async {
    try {
      await Future.delayed(const Duration(seconds: 1));
      return const Right(null);
    } catch (e) {
      return Left(ServerFailure(e.toString()));
    }
  }

  @override
  Future<Either<Failure, List<NotificationEntity>>> getNotifications() async {
    try {
      await Future.delayed(const Duration(seconds: 1));
      final List<NotificationModel> mockNotifications = [
        const NotificationModel(
          id: 'not_01',
          title: 'تحديث من المتجر 🧑‍🍳🔥',
          body: 'طلبك رقم #201 الآن قيد التحضير في المطبخ!',
          time: 'منذ دقيقة',
        ),
      ];
      return Right(mockNotifications);
    } catch (e) {
      return Left(ServerFailure(e.toString()));
    }
  }

  // يتبع مباشرة وتلقائياً الجزء 2 من 2 لإكمال كتل التحديث والمحاكاة الحية...
  @override
  Future<Either<Failure, void>> submitOrderEvaluation(
    EvaluationEntity evaluation,
  ) async {
    try {
      await Future.delayed(const Duration(milliseconds: 500));
      return const Right(null);
    } catch (e) {
      return Left(ServerFailure(e.toString()));
    }
  }

  @override
  Future<Either<Failure, List<PastOrderEntity>>> getOrderHistory() async {
    try {
      await Future.delayed(const Duration(seconds: 1));
      final List<PastOrderModel> mockHistory = [
        const PastOrderModel(
          orderCode: '00000021',
          dateTime: '2026-10-10 14:30',
          orderDetails: 'وجبة سوبر كومبو حار 🍔🔥',
          pickupLocation: 'مطعم البرجر الاحترافي سمنود',
          deliveryLocation: 'المنزل - شارع بورسعيد',
          deliveryFee: 35.0,
          driverRating: 5.0,
          storeRating: 4.5,
        ),
      ];
      return Right(mockHistory);
    } catch (e) {
      return Left(ServerFailure(e.toString()));
    }
  }

  @override
  Future<Either<Failure, List<MessageEntity>>> getChatMessages(
    String orderId,
  ) async {
    try {
      await Future.delayed(const Duration(milliseconds: 400));
      final List<MessageModel> mockMessages = [
        const MessageModel(
          messageId: 'msg_1',
          senderId: 'driver',
          text: 'السلام عليكم يا فندم، أنا استلمت الطلب الحر وتحركت الآن 🚴',
          timestamp: '12:55 م',
        ),
      ];
      return Right(mockMessages);
    } catch (e) {
      return Left(ServerFailure(e.toString()));
    }
  }

  @override
  Future<Either<Failure, void>> sendChatMessage(
    String orderId,
    MessageEntity message,
  ) async {
    try {
      await Future.delayed(const Duration(milliseconds: 200));
      debugPrint('الطلب: $orderId | النص: ${message.text}');
      return const Right(null);
    } catch (e) {
      return Left(ServerFailure(e.toString()));
    }
  }

  @override
  Future<Either<Failure, List<AddressEntity>>> getSavedAddresses() async {
    try {
      await Future.delayed(const Duration(milliseconds: 600));
      final List<AddressModel> mockAddresses = [
        const AddressModel(
          id: 'addr_01',
          title: 'المنزل 🏠',
          fullAddress: 'شارع بورسعيد - بجوار صيدلية الأمانة',
          city: 'سمنود',
          latitude: 30.9575,
          longitude: 31.2594,
        ),
      ];
      return Right(mockAddresses);
    } catch (e) {
      return Left(ServerFailure(e.toString()));
    }
  }

  @override
  Future<Either<Failure, void>> saveNewAddress(AddressEntity address) async {
    try {
      await Future.delayed(const Duration(milliseconds: 500));
      return const Right(null);
    } catch (e) {
      return Left(ServerFailure(e.toString()));
    }
  }

  // --- الدالة الجديدة المضافة: تنفيذ محاكاة تحديث الحساب الشخصي للعميل 2026 ---
  @override
  Future<Either<Failure, void>> updateCustomerProfile({
    required String name,
    required String phone,
  }) async {
    try {
      // محاكاة تأخير الشبكة لحفظ البيانات بقواعد البيانات
      await Future.delayed(const Duration(milliseconds: 600));

      debugPrint('--- [نظام الحساب والرقابة الحية 2026] ---');
      debugPrint('تم تحديث اسم الحساب إلى: $name');
      debugPrint('تم تحديث رقم الهاتف إلى: $phone');

      return const Right(null);
    } catch (e) {
      return Left(ServerFailure(e.toString()));
    }
  }
}
