import 'package:flutter/material.dart';

class PharmacyPage extends StatefulWidget {
  const PharmacyPage({super.key});

  @override
  State<PharmacyPage> createState() => _PharmacyPageState();
}

class _PharmacyPageState extends State<PharmacyPage> {
  final TextEditingController _searchController = TextEditingController();

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF8F9FA),
      // 1. شريط الترويسة العلوي لقسم الصيدلية
      appBar: AppBar(
        title: const Text(
          'الصيدلية والرعاية الصحية 💊',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            color: Colors.black87,
            fontFamily: 'Cairo',
          ),
        ),
        centerTitle: true,
        backgroundColor: Colors.white,
        elevation: 0.5,
        leading: IconButton(
          icon: const Icon(
            Icons.arrow_back_ios_new_rounded,
            color: Colors.black87,
          ),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // 2. شريط البحث عن الصيدليات النشطة في نطاق 30 كم
              SearchBar(
                controller: _searchController,
                hintText: 'ابحث عن صيدلية معينة...',
                hintStyle: WidgetStateProperty.all(
                  const TextStyle(
                    color: Colors.grey,
                    fontFamily: 'Cairo',
                    fontSize: 14,
                  ),
                ),
                padding: WidgetStateProperty.all(
                  const EdgeInsets.symmetric(horizontal: 16),
                ),
                backgroundColor: WidgetStateProperty.all(Colors.white),
                elevation: WidgetStateProperty.all(0.5),
                leading: const Icon(
                  Icons.search_rounded,
                  color: Colors.deepOrange,
                ),
                shape: WidgetStateProperty.all(
                  RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
              ),
              const SizedBox(height: 24),

              // سيتم استدعاء شبكة الصيدليات المتاحة وبوابة التحويل هنا في الجزء الثاني...
              // 3. ترويسة قائمة الصيدليات المتاحة
              const Text(
                'الصيدليات المتوفرة بالقرب منك',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: Colors.black87,
                  fontFamily: 'Cairo',
                ),
              ),
              const SizedBox(height: 16),

              // 4. بطاقة تحفيزية ذكية للطلب الحر للاحتياجات الطبية الطارئة
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.orange.withValues(alpha: 0.08),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(
                    color: Colors.orange.withValues(alpha: 0.2),
                    width: 1,
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        const Icon(
                          Icons.stars_rounded,
                          color: Colors.orange,
                          size: 24,
                        ),
                        const SizedBox(width: 8),
                        const Text(
                          'ملقيتش الصيدلية المطلوبة؟',
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.bold,
                            color: Colors.black87,
                            fontFamily: 'Cairo',
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'استخدم ميزة "الطلب الحر"؛ اكتب اسم أي صيدلية أو روشتة علاج والمندوب هيشتري الأدوية والمستلزمات الطبية ويوصلها ليك فوراً في نطاق ٣٠ كم!',
                      style: TextStyle(
                        fontSize: 12,
                        color: Colors.black54,
                        height: 1.5,
                        fontFamily: 'Cairo',
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24),

              // 5. قائمة عرض الصيدليات المتاحة (محاكاة دقيقة لتصميم احترافي لعام 2026)
              GridView.count(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                crossAxisCount: 2,
                crossAxisSpacing: 12,
                mainAxisSpacing: 12,
                childAspectRatio: 0.8,
                children: [
                  _buildPharmacyCard(
                    name: 'صيدليات العزبي',
                    description: 'خدمة ٢٤ ساعة وتوفير جميع الأدوية',
                    rating: '4.9',
                    imageIcon: Icons.health_and_safety_rounded,
                  ),
                  _buildPharmacyCard(
                    name: 'صيدليات مصر',
                    description: 'مستحضرات تجميل ورعاية صحية متكاملة',
                    rating: '4.7',
                    imageIcon: Icons.medical_services_rounded,
                  ),
                  _buildPharmacyCard(
                    name: 'صيدلية رشدي',
                    description: 'أدوية محلية ومستوردة للأمراض المزمنة',
                    rating: '4.6',
                    imageIcon: Icons.vaccines_rounded,
                  ),
                  _buildPharmacyCard(
                    name: 'صيدلية سيف',
                    description: 'مستلزمات أطفال وعناية يومية طارئة',
                    rating: '4.5',
                    imageIcon: Icons.healing_rounded,
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ودجت بناء كروت الصيدليات بطريقة جذابة وموحدة
  Widget _buildPharmacyCard({
    required String name,
    required String description,
    required String rating,
    required IconData imageIcon,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.02),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
        border: Border.all(
          color: Colors.grey.withValues(alpha: 0.08),
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // خلفية أيقونية تعبيرية لقسم الرعاية الطبية
          Expanded(
            flex: 5,
            child: Container(
              decoration: BoxDecoration(
                color: Colors.deepOrange.withValues(alpha: 0.05),
                borderRadius: const BorderRadius.vertical(
                  top: Radius.circular(16),
                ),
              ),
              child: Center(
                child: Icon(imageIcon, size: 48, color: Colors.deepOrange),
              ),
            ),
          ),
          // معلومات الصيدلية النصية بداخل الكارت
          Expanded(
            flex: 5,
            child: Padding(
              padding: const EdgeInsets.all(10.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        name,
                        style: const TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                          color: Colors.black87,
                          fontFamily: 'Cairo',
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 2),
                      Text(
                        description,
                        style: const TextStyle(
                          fontSize: 11,
                          color: Colors.grey,
                          fontFamily: 'Cairo',
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                  // التقييم الذكي بأسفل كارت العرض
                  Row(
                    children: [
                      const Icon(
                        Icons.star_rounded,
                        color: Colors.amber,
                        size: 16,
                      ),
                      const SizedBox(width: 4),
                      Text(
                        rating,
                        style: const TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                          color: Colors.black87,
                          fontFamily: 'Cairo',
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
