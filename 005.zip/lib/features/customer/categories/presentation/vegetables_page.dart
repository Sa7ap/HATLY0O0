import 'package:flutter/material.dart';

class VegetablesPage extends StatefulWidget {
  const VegetablesPage({super.key});

  @override
  State<VegetablesPage> createState() => _VegetablesPageState();
}

class _VegetablesPageState extends State<VegetablesPage> {
  final TextEditingController _searchController = TextEditingController();

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF8F9FA),
      // 1. شريط الترويسة العلوي لقسم الخضروات والفواكه
      appBar: AppBar(
        title: const Text(
          'الخضروات والفواكه 🍎',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            color: Colors.black87,
            fontFamily: 'Cairo',
          ),
        ),
        centerTitle: true,
        backgroundColor: Colors.white,
        elevation: 0.5,
        leading: IconButton(
          icon: const Icon(
            Icons.arrow_back_ios_new_rounded,
            color: Colors.black87,
          ),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // 2. شريط البحث عن محلات وأسواق الخضار الطازجة في نطاق 30 كم
              SearchBar(
                controller: _searchController,
                hintText: 'ابحث عن محل خضار أو فاكهة معين...',
                hintStyle: WidgetStateProperty.all(
                  const TextStyle(
                    color: Colors.grey,
                    fontFamily: 'Cairo',
                    fontSize: 14,
                  ),
                ),
                padding: WidgetStateProperty.all(
                  const EdgeInsets.symmetric(horizontal: 16),
                ),
                backgroundColor: WidgetStateProperty.all(Colors.white),
                elevation: WidgetStateProperty.all(0.5),
                leading: const Icon(
                  Icons.search_rounded,
                  color: Colors.deepOrange,
                ),
                shape: WidgetStateProperty.all(
                  RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
              ),
              const SizedBox(height: 24),

              // سيتم استدعاء قائمة البطاقات وبوابة التحويل هنا في الجزء الثاني...
              // 3. ترويسة قائمة أسواق الخضروات المتاحة
              const Text(
                'أسواق الخضار والفاكهة بالقرب منك',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: Colors.black87,
                  fontFamily: 'Cairo',
                ),
              ),
              const SizedBox(height: 16),

              // 4. بطاقة تحفيزية ذكية للطلب الحر إذا لم يجد العميل المحل مسجلاً
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.orange.withValues(alpha: 0.08),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(
                    color: Colors.orange.withValues(alpha: 0.2),
                    width: 1,
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        const Icon(
                          Icons.stars_rounded,
                          color: Colors.orange,
                          size: 24,
                        ),
                        const SizedBox(width: 8),
                        const Text(
                          'ملقيتش محل الخضار المفضل؟',
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.bold,
                            color: Colors.black87,
                            fontFamily: 'Cairo',
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'استخدم ميزة "الطلب الحر"؛ اكتب اسم أي بائع أو سوق خضار والمندوب هيشتري طلباتك الطازجة ويوصلها ليك فوراً في محيط ٣٠ كم!',
                      style: TextStyle(
                        fontSize: 12,
                        color: Colors.black54,
                        height: 1.5,
                        fontFamily: 'Cairo',
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24),

              // 5. قائمة عرض محلات الخضار المتاحة (محاكاة دقيقة لتصميم احترافي)
              GridView.count(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                crossAxisCount: 2,
                crossAxisSpacing: 12,
                mainAxisSpacing: 12,
                childAspectRatio: 0.8,
                children: [
                  _buildVegetableCard(
                    name: 'سوق أولاد مفتاح',
                    description: 'خضروات وفاكهة طازجة يومياً',
                    rating: '4.9',
                    imageIcon: Icons.eco_rounded,
                  ),
                  _buildVegetableCard(
                    name: 'ثمار الجنة',
                    description: 'فواكه مستوردة ومحلية فاخرة',
                    rating: '4.7',
                    imageIcon: Icons.apple_rounded,
                  ),
                  _buildVegetableCard(
                    name: 'خضروات الأمانة',
                    description: 'ورقيات ومستلزمات الطهي الطازجة',
                    rating: '4.6',
                    imageIcon: Icons.grass_rounded,
                  ),
                  _buildVegetableCard(
                    name: 'فاكهة أكتوبر',
                    description: 'عروض متميزة على كرتونة الفاكهة',
                    rating: '4.5',
                    imageIcon: Icons.shopping_bag_rounded,
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ودجت بناء كروت الخضروات بطريقة جذابة وموحدة
  Widget _buildVegetableCard({
    required String name,
    required String description,
    required String rating,
    required IconData imageIcon,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.02),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
        border: Border.all(
          color: Colors.grey.withValues(alpha: 0.08),
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // خلفية أيقونية تعبيرية للقسم
          Expanded(
            flex: 5,
            child: Container(
              decoration: BoxDecoration(
                color: Colors.deepOrange.withValues(alpha: 0.05),
                borderRadius: const BorderRadius.vertical(
                  top: Radius.circular(16),
                ),
              ),
              child: Center(
                child: Icon(imageIcon, size: 48, color: Colors.deepOrange),
              ),
            ),
          ),
          // معلومات المحل النصية بداخل الكارت
          Expanded(
            flex: 5,
            child: Padding(
              padding: const EdgeInsets.all(10.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        name,
                        style: const TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                          color: Colors.black87,
                          fontFamily: 'Cairo',
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 2),
                      Text(
                        description,
                        style: const TextStyle(
                          fontSize: 11,
                          color: Colors.grey,
                          fontFamily: 'Cairo',
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                  // التقييم الذكي بأسفل كارت العرض
                  Row(
                    children: [
                      const Icon(
                        Icons.star_rounded,
                        color: Colors.amber,
                        size: 16,
                      ),
                      const SizedBox(width: 4),
                      Text(
                        rating,
                        style: const TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                          color: Colors.black87,
                          fontFamily: 'Cairo',
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
