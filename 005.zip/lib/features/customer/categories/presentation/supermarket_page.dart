import 'package:flutter/material.dart';

class SupermarketPage extends StatefulWidget {
  const SupermarketPage({super.key});

  @override
  State<SupermarketPage> createState() => _SupermarketPageState();
}

class _SupermarketPageState extends State<SupermarketPage> {
  final TextEditingController _searchController = TextEditingController();

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF8F9FA),
      // 1. شريط الترويسة العلوي لقسم السوبرماركت
      appBar: AppBar(
        title: const Text(
          'السوبرماركت والماركت 🛒',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            color: Colors.black87,
            fontFamily: 'Cairo',
          ),
        ),
        centerTitle: true,
        backgroundColor: Colors.white,
        elevation: 0.5,
        leading: IconButton(
          icon: const Icon(
            Icons.arrow_back_ios_new_rounded,
            color: Colors.black87,
          ),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // 2. شريط البحث عن المحلات التجارية والهايبر ماركت في نطاق 30 كم
              SearchBar(
                controller: _searchController,
                hintText: 'ابحث عن سوبرماركت أو ماركت معين...',
                hintStyle: WidgetStateProperty.all(
                  const TextStyle(
                    color: Colors.grey,
                    fontFamily: 'Cairo',
                    fontSize: 14,
                  ),
                ),
                padding: WidgetStateProperty.all(
                  const EdgeInsets.symmetric(horizontal: 16),
                ),
                backgroundColor: WidgetStateProperty.all(Colors.white),
                elevation: WidgetStateProperty.all(0.5),
                leading: const Icon(
                  Icons.search_rounded,
                  color: Colors.deepOrange,
                ),
                shape: WidgetStateProperty.all(
                  RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
              ),
              const SizedBox(height: 24),

              // سيتم استدعاء شبكة الماركات النشطة وبوابة التحويل هنا في الجزء الثاني...
              // 3. ترويسة قائمة المحلات التجارية المتاحة
              const Text(
                'المحلات التجارية المتوفرة بالقرب منك',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: Colors.black87,
                  fontFamily: 'Cairo',
                ),
              ),
              const SizedBox(height: 16),

              // 4. بطاقة تحفيزية ذكية للطلب الحر إذا لم يجد العميل الماركت مسجلاً
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.orange.withValues(alpha: 0.08),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(
                    color: Colors.orange.withValues(alpha: 0.2),
                    width: 1,
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        const Icon(
                          Icons.stars_rounded,
                          color: Colors.orange,
                          size: 24,
                        ),
                        const SizedBox(width: 8),
                        const Text(
                          'ملقيتش السوبرماركت المطلوب؟',
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.bold,
                            color: Colors.black87,
                            fontFamily: 'Cairo',
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'استخدم ميزة "الطلب الحر"؛ اكتب اسم أي ماركت أو بقالة والمندوب هيشتري طلبات البيت ويوصلها ليك فوراً في نطاق ٣٠ كم!',
                      style: TextStyle(
                        fontSize: 12,
                        color: Colors.black54,
                        height: 1.5,
                        fontFamily: 'Cairo',
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24),

              // 5. قائمة عرض السوبرماركت المتاحة (محاكاة دقيقة لتصميم احترافي)
              GridView.count(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                crossAxisCount: 2,
                crossAxisSpacing: 12,
                mainAxisSpacing: 12,
                childAspectRatio: 0.8,
                children: [
                  _buildSupermarketCard(
                    name: 'هايبر وان',
                    description: 'جميع المنتجات الغذائية والمنزلية',
                    rating: '4.9',
                    imageIcon: Icons.local_mall_rounded,
                  ),
                  _buildSupermarketCard(
                    name: 'كارفور ماركت',
                    description: 'منتجات طازجة ومستلزمات يومية',
                    rating: '4.7',
                    imageIcon: Icons.shopping_basket_rounded,
                  ),
                  _buildSupermarketCard(
                    name: 'سوبرماركت أولاد رجب',
                    description: 'أجبان ومعلبات وعروض متنوعة',
                    rating: '4.6',
                    imageIcon: Icons.storefront_rounded,
                  ),
                  _buildSupermarketCard(
                    name: 'ماركت الفرجاني',
                    description: 'سلع تموينية ومواد غذائية',
                    rating: '4.5',
                    imageIcon: Icons.local_grocery_store_rounded,
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ودجت بناء كروت السوبرماركت بطريقة جذابة وموحدة
  Widget _buildSupermarketCard({
    required String name,
    required String description,
    required String rating,
    required IconData imageIcon,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.02),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
        border: Border.all(
          color: Colors.grey.withValues(alpha: 0.08),
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // خلفية أيقونية تعبيرية للسوبرماركت
          Expanded(
            flex: 5,
            child: Container(
              decoration: BoxDecoration(
                color: Colors.deepOrange.withValues(alpha: 0.05),
                borderRadius: const BorderRadius.vertical(
                  top: Radius.circular(16),
                ),
              ),
              child: Center(
                child: Icon(imageIcon, size: 48, color: Colors.deepOrange),
              ),
            ),
          ),
          // معلومات السوبرماركت النصية بداخل الكارت
          Expanded(
            flex: 5,
            child: Padding(
              padding: const EdgeInsets.all(10.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        name,
                        style: const TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                          color: Colors.black87,
                          fontFamily: 'Cairo',
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 2),
                      Text(
                        description,
                        style: const TextStyle(
                          fontSize: 11,
                          color: Colors.grey,
                          fontFamily: 'Cairo',
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                  // التقييم الذكي بأسفل كارت العرض
                  Row(
                    children: [
                      const Icon(
                        Icons.star_rounded,
                        color: Colors.amber,
                        size: 16,
                      ),
                      const SizedBox(width: 4),
                      Text(
                        rating,
                        style: const TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                          color: Colors.black87,
                          fontFamily: 'Cairo',
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
