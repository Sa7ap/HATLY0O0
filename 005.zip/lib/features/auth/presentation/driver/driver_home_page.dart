import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:hatlyai/features/customer/customer_orders/presentation/bloc/customer_order_bloc.dart';
import 'package:hatlyai/features/customer/customer_orders/presentation/bloc/customer_order_state.dart';
import 'package:hatlyai/features/customer/customer_orders/presentation/bloc/customer_order_event.dart';

import 'wallet_bloc/driver_wallet_bloc.dart';
import 'wallet_bloc/driver_wallet_event.dart';
import 'wallet_bloc/driver_wallet_state.dart';
import '../../domain/entities/driver_shift_entity.dart';

class DriverHomePage extends StatefulWidget {
  const DriverHomePage({super.key});

  @override
  State<DriverHomePage> createState() => _DriverHomePageState();
}

class _DriverHomePageState extends State<DriverHomePage> {
  bool _isOnline = true;

  @override
  void initState() {
    super.initState();
    // إطلاق استعلام الرصيد التراكمي وكشف حساب ورديات المندوب الفورية معاً
    context.read<DriverWalletBloc>().add(GetDriverWalletRequestedEvent());
    context.read<DriverWalletBloc>().add(GetDriverShiftsRequestedEvent());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF8F9FA),
      // شريط الترويسة التفاعلي الموثق بحالة التوصيل الحالية
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0.5,
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: _isOnline
                    ? Colors.green.withOpacity(0.1)
                    : Colors.grey.withOpacity(0.1),
                shape: BoxShape.circle,
              ),
              child: Icon(
                Icons.local_shipping_rounded,
                color: _isOnline ? Colors.green : Colors.grey,
                size: 24,
              ),
            ),
            const SizedBox(width: 12),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'لوحة تحكم الكابتن',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: Colors.black87,
                    fontFamily: 'Cairo',
                  ),
                ),
                Text(
                  _isOnline
                      ? 'متاح لاستقبال طلبات محيط 30 كم'
                      : 'أنت غير متصل الآن',
                  style: TextStyle(
                    fontSize: 12,
                    color: _isOnline ? Colors.green : Colors.grey,
                    fontFamily: 'Cairo',
                  ),
                ),
              ],
            ),
          ],
        ),
        actions: [
          Switch.adaptive(
            value: _isOnline,
            activeColor: Colors.green,
            onChanged: (value) {
              setState(() {
                _isOnline = value;
              });
            },
          ),
        ],
      ),
      // سيتم استدعاء شريان الـ body وكروت الأرباح في الجزء الثاني...
      body: SafeArea(
        child: _isOnline
            ? BlocBuilder<DriverWalletBloc, DriverWalletState>(
                builder: (context, walletState) {
                  double totalEarnings = 0.0;
                  double availableBalance = 0.0;
                  int completedOrders = 0;
                  List<DriverShiftEntity> shiftsList = [];

                  // 3. استخراج البيانات المالية التراكمية فور نجاح الحالة الموثقة
                  if (walletState is GetDriverWalletSuccessState) {
                    totalEarnings = walletState.wallet.totalEarnings;
                    availableBalance = walletState.wallet.availableBalance;
                    completedOrders = walletState.wallet.completedOrders;
                  }

                  // 4. استخراج مصفوفة ورديات كشف الحساب الحية فور تحميلها بنجاح
                  if (walletState is GetDriverShiftsSuccessState) {
                    shiftsList = walletState.shifts;
                  }

                  if (walletState is DriverWalletLoadingState &&
                      totalEarnings == 0.0) {
                    return const Center(
                      child: CircularProgressIndicator(color: Colors.green),
                    );
                  }

                  return SingleChildScrollView(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // كارت إحصائيات الأرباح التراكمية العلوية للمندوب
                        Container(
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(16),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withOpacity(0.02),
                                blurRadius: 10,
                                offset: const Offset(0, 4),
                              ),
                            ],
                            border: Border.all(
                              color: Colors.grey.withOpacity(0.05),
                            ),
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            children: [
                              _buildStatItem(
                                title: 'إجمالي الأرباح',
                                value:
                                    '${totalEarnings.toStringAsFixed(0)} ج.م',
                                icon: Icons.monetization_on_rounded,
                                iconColor: Colors.amber,
                              ),
                              Container(
                                width: 1,
                                height: 40,
                                color: Colors.grey.withOpacity(0.2),
                              ),
                              _buildStatItem(
                                title: 'رصيد متاح للسحب',
                                value:
                                    '${availableBalance.toStringAsFixed(0)} ج.م',
                                icon: Icons.account_balance_wallet_rounded,
                                iconColor: Colors.green,
                              ),
                              Container(
                                width: 1,
                                height: 40,
                                color: Colors.grey.withOpacity(0.2),
                              ),
                              _buildStatItem(
                                title: 'طلبات مكتملة',
                                value: '$completedOrders طلب',
                                icon: Icons.verified_rounded,
                                iconColor: Colors.blue,
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 24),

                        // 5. قسم استقبال وعرض كروت الطلبات الحرة الجغرافية الفورية
                        const Text(
                          'الطلبات الحرة المتاحة بالقرب منك',
                          style: TextStyle(
                            fontSize: 15,
                            fontWeight: FontWeight.bold,
                            color: Colors.black87,
                            fontFamily: 'Cairo',
                          ),
                        ),
                        const SizedBox(height: 12),
                        BlocConsumer<CustomerOrderBloc, CustomerOrderState>(
                          listener: (context, orderState) {
                            if (orderState is UpdateOrderStatusSuccessState) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                  content: Text(
                                    'تم قبول الطلب رقم (${orderState.orderId}) بنجاح! 🏁',
                                  ),
                                  backgroundColor: Colors.green,
                                ),
                              );
                            }
                          },
                          builder: (context, orderState) {
                            final isOrderLoading =
                                orderState is CustomerOrderLoadingState;
                            return _buildOrderCard(
                              orderId: "101",
                              orderDetails: 'شراء ٢ كيلو تفاح أمريكي وعلبة عصير لتر تفاح مجفف.',
                              storeName: 'أي متجر متاح (يختاره المندوب)',
                              itemsPrice: '50 ج.م',
                              deliveryFee: '35 ج.م',
                              distance: '4.2 كم في المحيط',
                              isAnyStore: true,
                              isLoading: isOrderLoading,
                            );
                          },
                        ),
                        const SizedBox(height: 28),
                        // سيتم حقن سجل الورديات والودجات المساعدة في الجزء الثالث والأخير...
                        // 6. قسم كشف حساب الورديات والرحلات الجغرافية التفصيلية الجديد
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Text(
                              'سجل الورديات والرحلات الأخيرة 📄',
                              style: TextStyle(
                                fontSize: 15,
                                fontWeight: FontWeight.bold,
                                color: Colors.black87,
                                fontFamily: 'Cairo',
                              ),
                            ),
                            TextButton(
                              onPressed: () {
                                context.read<DriverWalletBloc>().add(
                                  GetDriverShiftsRequestedEvent(),
                                );
                              },
                              child: const Text(
                                'تحديث السجل',
                                style: TextStyle(
                                  color: Colors.green,
                                  fontFamily: 'Cairo',
                                  fontSize: 13,
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 8),

                        shiftsList.isEmpty
                            ? const Center(
                                child: Padding(
                                  padding: EdgeInsets.all(16.0),
                                  child: Text(
                                    'لا توجد ورديات مسجلة اليوم أو جاري جلبها... 🔄',
                                    style: TextStyle(
                                      color: Colors.grey,
                                      fontFamily: 'Cairo',
                                      fontSize: 12,
                                    ),
                                  ),
                                ),
                              )
                            : ListView.builder(
                                shrinkWrap: true,
                                physics: const NeverScrollableScrollPhysics(),
                                itemCount: shiftsList.length,
                                itemBuilder: (context, index) {
                                  final shift = shiftsList[index];
                                  return _buildShiftRowItem(shift);
                                },
                              ),
                      ],
                    ),
                  );
                },
              )
            : Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      Icons.portable_wifi_off_rounded,
                      size: 64,
                      color: Colors.grey.withOpacity(0.4),
                    ),
                    const SizedBox(height: 16),
                    const Text(
                      'قم بتفعيل وضع الاتصال بالخارج\nلاستقبال طلبات العملاء الحرة في نطاق 30 كم.',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 15,
                        color: Colors.grey,
                        height: 1.5,
                        fontFamily: 'Cairo',
                      ),
                    ),
                  ],
                ),
              ),
      ),
    );
  }

  // ودجت بناء وتنسيق عناصر الإحصائيات العلوية بنقاء
  Widget _buildStatItem({
    required String title,
    required String value,
    required IconData icon,
    required Color iconColor,
  }) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon, color: iconColor, size: 20),
        const SizedBox(height: 4),
        Text(
          title,
          style: const TextStyle(
            fontSize: 10,
            color: Colors.grey,
            fontFamily: 'Cairo',
          ),
        ),
        const SizedBox(height: 2),
        Text(
          value,
          style: const TextStyle(
            fontSize: 13,
            fontWeight: FontWeight.bold,
            color: Colors.black87,
            fontFamily: 'Cairo',
          ),
        ),
      ],
    );
  }

  // ودجت تصميم كروت وحركات كشف حساب ورديات الكابتن بنقاء كلي
  Widget _buildShiftRowItem(DriverShiftEntity shift) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.grey.withOpacity(0.05)),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: Colors.green.withOpacity(0.08),
              shape: BoxShape.circle,
            ),
            child: const Icon(
              Icons.local_shipping_outlined,
              color: Colors.green,
              size: 20,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  shift.orderSummary,
                  style: const TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Cairo',
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 4),
                Text(
                  '${shift.date} • مسافة: ${shift.distance}',
                  style: const TextStyle(
                    fontSize: 10,
                    color: Colors.grey,
                    fontFamily: 'Cairo',
                  ),
                ),
              ],
            ),
          ),
          Text(
            '+${shift.deliveryEarnings.toStringAsFixed(0)} ج.م',
            style: const TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.bold,
              color: Colors.green,
              fontFamily: 'Cairo',
            ),
          ),
        ],
      ),
    );
  }

  // ودجت بناء واستقبال كروت الطلبات الحرة الجغرافية المتاحة في محيط الكابتن
  Widget _buildOrderCard({
    required String orderId,
    required String orderDetails,
    required String storeName,
    required String itemsPrice,
    required String deliveryFee,
    required String distance,
    required bool isAnyStore,
    required bool isLoading,
  }) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: isAnyStore
              ? Colors.orange.withOpacity(0.2)
              : Colors.grey.withOpacity(0.1),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                isAnyStore ? '📍 شراء من أي مكان' : '🏢 متجر محدد للطلب',
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.bold,
                  color: isAnyStore ? Colors.orange : Colors.blue,
                  fontFamily: 'Cairo',
                ),
              ),
              Text(
                distance,
                style: const TextStyle(
                  fontSize: 13,
                  color: Colors.grey,
                  fontWeight: FontWeight.w600,
                  fontFamily: 'Cairo',
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            storeName,
            style: const TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.bold,
              fontFamily: 'Cairo',
            ),
          ),
          const Divider(height: 20),
          Text(
            orderDetails,
            style: const TextStyle(
              fontSize: 13,
              color: Colors.black87,
              fontFamily: 'Cairo',
            ),
          ),
          const Divider(height: 20),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'ربح التوصيل: $deliveryFee',
                style: const TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  color: Colors.green,
                  fontFamily: 'Cairo',
                ),
              ),
              ElevatedButton(
                onPressed: isLoading
                    ? null
                    : () {
                        context.read<CustomerOrderBloc>().add(
                          UpdateOrderStatusRequestedEvent(
                            orderId: orderId,
                            newStatus: 'accepted',
                          ),
                        );
                      },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                child: isLoading
                    ? const SizedBox(
                        width: 20,
                        height: 20,
                        child: CircularProgressIndicator(
                          color: Colors.white,
                          strokeWidth: 2,
                        ),
                      )
                    : const Text(
                        'قبول الطلب',
                        style: TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'Cairo',
                        ),
                      ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
