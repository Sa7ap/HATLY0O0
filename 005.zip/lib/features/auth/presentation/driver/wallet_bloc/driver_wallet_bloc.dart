import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../domain/usecases/get_driver_wallet_usecase.dart';
import '../../../domain/usecases/get_driver_shifts_usecase.dart'; // استدعاء حالة استخدام كشف الورديات الجديدة
import 'driver_wallet_event.dart';
import 'driver_wallet_state.dart';

class DriverWalletBloc extends Bloc<DriverWalletEvent, DriverWalletState> {
  final GetDriverWalletUseCase getDriverWalletUseCase;
  final GetDriverShiftsUseCase
  getDriverShiftsUseCase; // حقن التبعية الجديدة لورديات الكابتن

  DriverWalletBloc({
    required this.getDriverWalletUseCase,
    required this.getDriverShiftsUseCase, // إلزام التبعية في الـ Constructor
  }) : super(DriverWalletInitialState()) {
    // 1. معالجة حدث طلب جلب إحصائيات محفظة المندوب التراكمية (الـ 450 ج.م والـ 12 طلباً)
    on<GetDriverWalletRequestedEvent>((event, emit) async {
      emit(DriverWalletLoadingState());
      final result = await getDriverWalletUseCase.call();
      result.fold(
        (failure) =>
            emit(DriverWalletFailureState(errorMessage: failure.message)),
        (wallet) => emit(GetDriverWalletSuccessState(wallet)),
      );
    });

    // 2. معالجة حدث طلب جلب كشف حساب الورديات والرحلات الجغرافية التفصيلية ديناميكياً
    on<GetDriverShiftsRequestedEvent>((event, emit) async {
      emit(DriverWalletLoadingState()); // تشغيل مؤشر التحميل الذكي

      final result = await getDriverShiftsUseCase.call();

      result.fold(
        (failure) =>
            emit(DriverWalletFailureState(errorMessage: failure.message)),
        (shifts) => emit(GetDriverShiftsSuccessState(shifts)),
      );
    });
  }
}
