import 'package:equatable/equatable.dart';

abstract class DriverWalletEvent extends Equatable {
  const DriverWalletEvent();

  @override
  List<Object?> get props => [];
}

// 1. الحدث القديم لطلب جلب إحصائيات محفظة المندوب التراكمية (الـ 450 ج.م والـ 12 طلباً)
class GetDriverWalletRequestedEvent extends DriverWalletEvent {}

// --- الحدث الجديد المضاف لإدارة كشف حساب ورديات المندوب حركياً لعام 2026 ---

// 2. حدث طلب جلب وتحديث قائمة الرحلات والورديات الجغرافية التفصيلية للكابتن
class GetDriverShiftsRequestedEvent extends DriverWalletEvent {}
