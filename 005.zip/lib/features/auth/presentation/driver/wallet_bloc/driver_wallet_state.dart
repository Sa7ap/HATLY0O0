import 'package:equatable/equatable.dart';

import '../../../domain/entities/driver_wallet_entity.dart';
import '../../../domain/entities/driver_shift_entity.dart'; // استدعاء كيان الورديات الجديد

abstract class DriverWalletState extends Equatable {
  const DriverWalletState();

  @override
  List<Object?> get props => [];
}

// 1. الحالات الابتدائية والتحميل العامة للمحفظة
class DriverWalletInitialState extends DriverWalletState {}

class DriverWalletLoadingState extends DriverWalletState {}

// 2. حالة نجاح جلب إحصائيات محفظة المندوب التراكمية (الـ 450 ج.م والـ 12 طلباً)
class GetDriverWalletSuccessState extends DriverWalletState {
  final DriverWalletEntity wallet;

  const GetDriverWalletSuccessState(this.wallet);

  @override
  List<Object?> get props => [wallet];
}

// --- الحالات الجديدة المضافة: لإدارة كشف حساب الورديات حركياً بنقاء تّام ---

// 3. حالة نجاح جلب وتحديث قائمة ورديات ورحلات الكابتن التفصيلية
class GetDriverShiftsSuccessState extends DriverWalletState {
  final List<DriverShiftEntity> shifts;

  const GetDriverShiftsSuccessState(this.shifts);

  @override
  List<Object?> get props => [shifts];
}

// 4. حالة حدوث خطأ مالي أو فشل في الاتصال بالسيرفر
class DriverWalletFailureState extends DriverWalletState {
  final String errorMessage;

  const DriverWalletFailureState({required this.errorMessage});

  @override
  List<Object?> get props => [errorMessage];
}
