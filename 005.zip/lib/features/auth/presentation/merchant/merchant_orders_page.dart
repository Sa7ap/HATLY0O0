import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import 'product_bloc/merchant_product_bloc.dart';
import 'product_bloc/merchant_product_event.dart';
import 'product_bloc/merchant_product_state.dart';
import '../../domain/entities/merchant_order_entity.dart';

class MerchantOrdersPage extends StatefulWidget {
  const MerchantOrdersPage({super.key});

  @override
  State<MerchantOrdersPage> createState() => _MerchantOrdersPageState();
}

class _MerchantOrdersPageState extends State<MerchantOrdersPage> {
  @override
  void initState() {
    super.initState();
    // 1. إطلاق حدث طلب جلب قائمة طلبات المتجر تلقائياً فور فتح الشاشة
    context.read<MerchantProductBloc>().add(GetMerchantOrdersEvent());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF8F9FA),
      // 2. شريط الترويسة العلوي الأنيق لبوابة الطلبات الفورية
      appBar: AppBar(
        elevation: 0.5,
        backgroundColor: Colors.white,
        title: const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'طلبات المتجر الواردة 🛒',
              style: TextStyle(
                fontSize: 15,
                fontWeight: FontWeight.bold,
                color: Colors.black87,
                fontFamily: 'Cairo',
              ),
            ),
            Text(
              'تتبع وإدارة طلبات العملاء الحية',
              style: TextStyle(
                fontSize: 11,
                color: Colors.grey,
                fontFamily: 'Cairo',
              ),
            ),
          ],
        ),
        centerTitle: false,
        leading: IconButton(
          icon: const Icon(
            Icons.arrow_back_ios_new_rounded,
            color: Colors.black87,
          ),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      // سيتم استدعاء الـ BlocConsumer وبناء قائمة الطلبات الحركية في الجزء الثاني...
      body: SafeArea(
        child: BlocConsumer<MerchantProductBloc, MerchantProductState>(
          listener: (context, state) {
            // 3. الاستماع لحالة نجاح تحديث وضعية الطهي والتحضير داخل المطبخ وعرض تنبيه أخضر للتاجر
            if (state is UpdateMerchantOrderStatusSuccessState) {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text(
                    'تم تحديث حالة الطلب رقم (${state.orderId}) بنجاح! 🧑‍🍳🔥',
                  ),
                  backgroundColor: Colors.green,
                ),
              );
              // إعادة جلب القائمة فوراً من السيرفر ليعرض الوضع الجديد المستقر للطلب
              context.read<MerchantProductBloc>().add(GetMerchantOrdersEvent());
            }
          },
          builder: (context, state) {
            List<MerchantOrderEntity> ordersList = [];

            // 4. استخراج مصفوفة الطلبات الواردة الحية فور تحميلها بنجاح من الـ Bloc
            if (state is GetMerchantOrdersSuccessState) {
              ordersList = state.orders;
            }

            if (state is MerchantProductLoadingState && ordersList.isEmpty) {
              return const Center(
                child: CircularProgressIndicator(color: Colors.deepOrange),
              );
            }

            return RefreshIndicator(
              onRefresh: () async {
                context.read<MerchantProductBloc>().add(
                  GetMerchantOrdersEvent(),
                );
              },
              color: Colors.deepOrange,
              child: ListView(
                padding: const EdgeInsets.all(16.0),
                children: [
                  // رسالة توضيحية لآلية العمل الفوري داخل المطبخ
                  Container(
                    padding: const EdgeInsets.all(12),
                    margin: const EdgeInsets.only(bottom: 20),
                    decoration: BoxDecoration(
                      color: Colors.deepOrange.withValues(alpha: 0.05),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Row(
                      children: [
                        Icon(
                          Icons.flash_on_rounded,
                          color: Colors.deepOrange,
                          size: 20,
                        ),
                        SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            'قم بتأكيد تحضير وجبات وسلع العملاء فوراً لكي يتحرك كابتن التوصيل الجغرافي لاستلامها.',
                            style: TextStyle(
                              fontSize: 12,
                              color: Colors.black87,
                              fontFamily: 'Cairo',
                              height: 1.4,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),

                  // عرض شكل توضيحي محمي إذا كانت قائمة الطلبات فارغة
                  ordersList.isEmpty
                      ? const Center(
                          child: Padding(
                            padding: EdgeInsets.symmetric(vertical: 40),
                            child: Text(
                              'لا توجد طلبات واردة لمتجرك حالياً.',
                              style: TextStyle(
                                fontFamily: 'Cairo',
                                color: Colors.grey,
                                fontSize: 13,
                              ),
                            ),
                          ),
                        )
                      : ListView.builder(
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          itemCount: ordersList.length,
                          itemBuilder: (context, index) {
                            final order = ordersList[index];
                            return _buildOrderCardItem(order);
                          },
                        ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }

  // سيتم إضافة الودجات المساعدة لبناء كروت الفواتير وحالات الطهي في الجزء الثالث والأخير...
  // ودجت بناء وتنسيق كروت الفواتير والطلبات الواردة للتاجر بنقاء
  Widget _buildOrderCardItem(MerchantOrderEntity order) {
    Color statusColor = Colors.orange;
    String statusText = 'قيد الانتظار ⏳';
    bool canPrepare = true;

    // تحديد الألوان والنصوص بناءً على حالة الطلب الحقيقية القادمة من البلوك
    if (order.status == 'preparing') {
      statusColor = Colors.blue;
      statusText = 'جاري التحضير 🧑‍🍳';
      canPrepare = false;
    } else if (order.status == 'ready') {
      statusColor = Colors.green;
      statusText = 'جاهز للاستلام 🏁';
      canPrepare = false;
    }

    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.grey.withValues(alpha: 0.08)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.01),
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // ١. رأس الكارت: رقم الفاتورة وحالة الطهي الحالية
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'طلب رقم: #${order.id.replaceAll('ord_', '')}',
                style: const TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Cairo',
                  color: Colors.black87,
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 6,
                ),
                decoration: BoxDecoration(
                  color: statusColor.withValues(alpha: 0.08),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  statusText,
                  style: TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.bold,
                    color: statusColor,
                    fontFamily: 'Cairo',
                  ),
                ),
              ),
            ],
          ),
          const Divider(height: 24, thickness: 0.8),

          // ٢. تفاصيل السلع والمنتجات المطلوبة من العميل
          const Text(
            'الأغراض المطلوبة:',
            style: TextStyle(
              fontSize: 12,
              color: Colors.grey,
              fontFamily: 'Cairo',
            ),
          ),
          const SizedBox(height: 6),
          Text(
            order.itemsSummary,
            style: const TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w600,
              color: Colors.black87,
              fontFamily: 'Cairo',
              height: 1.4,
            ),
          ),
          const Divider(height: 24, thickness: 0.8),

          // ٣. بيانات التواصل المالي ورقم الهاتف
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'حساب المنتجات الصافي:',
                    style: TextStyle(
                      fontSize: 11,
                      color: Colors.grey,
                      fontFamily: 'Cairo',
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    '${order.itemsPrice.toStringAsFixed(0)} ج.م',
                    style: const TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.bold,
                      color: Colors.green,
                      fontFamily: 'Cairo',
                    ),
                  ),
                ],
              ),

              // زر التحكم الحركي المتجاوب آلياً لتغيير حالة الطلب داخل المطبخ
              if (canPrepare)
                ElevatedButton.icon(
                  onPressed: () {
                    context.read<MerchantProductBloc>().add(
                      UpdateMerchantOrderStatusEvent(
                        orderId: order.id,
                        newStatus: 'preparing',
                      ),
                    );
                  },
                  icon: const Icon(Icons.soup_kitchen_rounded, size: 16),
                  label: const Text(
                    'تأكيد وبدء التحضير',
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Cairo',
                    ),
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.deepOrange,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(
                      horizontal: 16,
                      vertical: 10,
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                    elevation: 0,
                  ),
                )
              else if (order.status == 'preparing')
                ElevatedButton.icon(
                  onPressed: () {
                    context.read<MerchantProductBloc>().add(
                      UpdateMerchantOrderStatusEvent(
                        orderId: order.id,
                        newStatus: 'ready',
                      ),
                    );
                  },
                  icon: const Icon(Icons.gpp_good_rounded, size: 16),
                  label: const Text(
                    'جاهز للاستلام',
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Cairo',
                    ),
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.green,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(
                      horizontal: 16,
                      vertical: 10,
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                    elevation: 0,
                  ),
                )
              else
                const Text(
                  'بانتظار وصول الكابتن... 🔕',
                  style: TextStyle(
                    fontSize: 12,
                    color: Colors.grey,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Cairo',
                  ),
                ),
            ],
          ),
        ],
      ),
    );
  }
}
