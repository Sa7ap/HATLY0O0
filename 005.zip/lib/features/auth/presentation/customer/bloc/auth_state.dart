import '../../../domain/entities/user_entity.dart';

abstract class AuthState {
  const AuthState();
}

// الدالة الابتدائية للشاشة
class AuthInitialState extends AuthState {}

// حالة التحميل (انتظار رد السيرفر وعرض دائرة التحميل)
class AuthLoadingState extends AuthState {}

// حالة نجاح إرسال رقم الهاتف والانتقال لصفحة الـ OTP
class SendOtpSuccessState extends AuthState {}

// حالة نجاح التحقق والولوج للتطبيق كاملاً بنجاح
class VerifyOtpSuccessState extends AuthState {
  final UserEntity user;
  const VerifyOtpSuccessState(this.user);
}

// حالة حدوث خطأ (عرض رسالة الخطأ للمستخدم)
class AuthFailureState extends AuthState {
  final String errorMessage; // تم تصحيح الإملاء هنا بإضافة حرف r الثاني
  const AuthFailureState(this.errorMessage);
}
