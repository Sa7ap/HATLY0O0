abstract class AuthEvent {
  const AuthEvent();
}

// الحدث الأول: العميل ضغط على زر إرسال رقم الهاتف
class SendOtpRequestedEvent extends AuthEvent {
  final String phoneNumber;
  const SendOtpRequestedEvent(this.phoneNumber);
}

// الحدث الثاني: العميل ضغط على زر التحقق من الرمز
class VerifyOtpRequestedEvent extends AuthEvent {
  final String phoneNumber;
  final String otp;
  const VerifyOtpRequestedEvent({required this.phoneNumber, required this.otp});
}
