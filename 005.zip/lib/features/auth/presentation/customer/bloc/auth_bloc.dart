import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../domain/usecases/send_otp_usecase.dart'; // تم تصحيح المسار هنا
import '../../../domain/usecases/verify_otp_usecase.dart'; // تم تصحيح المسار هنا
import 'auth_event.dart';
import 'auth_state.dart';

class AuthBloc extends Bloc<AuthEvent, AuthState> {
  final SendOtpUseCase sendOtpUseCase;
  final VerifyOtpUseCase verifyOtpUseCase;

  AuthBloc({required this.sendOtpUseCase, required this.verifyOtpUseCase})
    : super(AuthInitialState()) {
    // ربط حدث إرسال الهاتف بمنطق العمل والـ UseCase
    on<SendOtpRequestedEvent>((event, emit) async {
      emit(AuthLoadingState());
      final result = await sendOtpUseCase.call(event.phoneNumber);

      result.fold(
        (failure) => emit(AuthFailureState(failure.message)),
        (_) => emit(SendOtpSuccessState()),
      );
    });

    // ربط حدث التحقق من الرمز بمنطق العمل والـ UseCase
    on<VerifyOtpRequestedEvent>((event, emit) async {
      emit(AuthLoadingState());
      final result = await verifyOtpUseCase.call(event.phoneNumber, event.otp);

      result.fold(
        (failure) => emit(AuthFailureState(failure.message)),
        (userEntity) => emit(VerifyOtpSuccessState(userEntity)),
      );
    });
  }
}
